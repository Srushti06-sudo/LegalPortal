from flask import (
    Flask,
    render_template,
    render_template_string,
    request,
    redirect,
    url_for,
    session
)

from datetime import date, datetime
from functools import wraps
import os
import secrets

from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash


# ============================================================
# APPLICATION
# ============================================================

app = Flask(__name__)

app.secret_key = os.environ.get(
    "SECRET_KEY",
    "legaldesk-dev-key-not-for-production"
)

OFFICE_NAME = "LegalDesk"

office_hours_text = "Monday - Saturday: 10:00 AM - 6:00 PM"

# ------------------------------------------------------------
# STAFF / ADVOCATE LOGIN CREDENTIALS
# ------------------------------------------------------------
# Passwords are hashed instead of stored/compared in plaintext.
# Change these via environment variables for a real deployment:
#   LEGALDESK_ADVOCATE_PASSWORD, LEGALDESK_STAFF_PASSWORD
ADVOCATE_EMAIL = "advocate@gmail.com"
ADVOCATE_PASSWORD_HASH = generate_password_hash(
    os.environ.get("LEGALDESK_ADVOCATE_PASSWORD", "Advocate@2026!")
)

STAFF_EMAIL = "staff@gmail.com"
STAFF_PASSWORD_HASH = generate_password_hash(
    os.environ.get("LEGALDESK_STAFF_PASSWORD", "OfficeStaff#77")
)


def _safe_check_password(stored_value, provided_password):
    """
    Verify a password against a stored hash. Returns False
    instead of raising if the stored value isn't a valid hash
    (e.g. leftover plaintext data from an older version).
    """
    try:
        return check_password_hash(stored_value, provided_password)
    except (ValueError, TypeError):
        return False


# ============================================================
# UPLOAD SETTINGS
# ============================================================

UPLOAD_FOLDER = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "static",
    "uploads"
)

os.makedirs(
    UPLOAD_FOLDER,
    exist_ok=True
)

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


# Allowed document extensions
ALLOWED_EXTENSIONS = {
    "pdf",
    "doc",
    "docx",
    "odt",
    "txt",
    "jpg",
    "jpeg",
    "png"
}


# ============================================================
# TEMPORARY DATA STORAGE
# ============================================================

clients = []

cases = []

hearings = []

appointments = []

payments = []

documents = []

communications = []


# ============================================================
# DEMO DATA
# ============================================================

def load_demo_data():

    # ========================================================
    # CLIENTS
    # ========================================================

    clients.clear()

    clients.extend([

        {
            "id": 1,
            "name": "Priya Sharma",
            "phone": "+91 98765 12345",
            "email": "client@gmail.com",
            "password": generate_password_hash("Priya@Legal92"),
            "address": "Nashik, Maharashtra",
            "case_type": "Civil Matter",
            "status": "Active"
        },

        {
            "id": 2,
            "name": "Rahul Patil",
            "phone": "+91 98765 45678",
            "email": "rahul@gmail.com",
            "password": generate_password_hash("Rahul#Case45"),
            "address": "Pune, Maharashtra",
            "case_type": "Property Dispute",
            "status": "Active"
        },

        {
            "id": 3,
            "name": "Sneha Joshi",
            "phone": "+91 91234 56789",
            "email": "sneha@gmail.com",
            "password": generate_password_hash("Sneha@Matter18"),
            "address": "Sinnar, Maharashtra",
            "case_type": "Family Matter",
            "status": "Active"
        }

    ])


    # ========================================================
    # CASES
    # ========================================================

    cases.clear()

    cases.extend([

        {
            "id": 1,
            "case_number": "LD-2026-001",
            "client_name": "Priya Sharma",
            "case_type": "Civil Matter",
            "court": "District Court, Nashik",
            "filing_date": "2026-07-10",
            "status": "Active",
            "description": "Civil property-related matter.",
            "fee_amount": 8000.00,
            "stage": 2
        },

        {
            "id": 2,
            "case_number": "LD-2026-002",
            "client_name": "Rahul Patil",
            "case_type": "Property Dispute",
            "court": "Civil Court, Pune",
            "filing_date": "2026-07-15",
            "status": "Active",
            "description": "Property ownership dispute.",
            "fee_amount": 7500.00,
            "stage": 3
        },

        {
            "id": 3,
            "case_number": "LD-2026-003",
            "client_name": "Sneha Joshi",
            "case_type": "Family Matter",
            "court": "Family Court, Nashik",
            "filing_date": "2026-07-22",
            "status": "Pending",
            "description": "Family legal matter.",
            "fee_amount": 6000.00,
            "stage": 1
        }

    ])


    # ========================================================
    # HEARINGS
    # ========================================================

    hearings.clear()

    hearings.extend([

        {
            "id": 1,
            "case_number": "LD-2026-001",
            "client_name": "Priya Sharma",
            "court": "District Court, Nashik",
            "date": "2026-08-25",
            "time": "10:30",
            "purpose": "Initial Hearing",
            "status": "Scheduled"
        },

        {
            "id": 2,
            "case_number": "LD-2026-002",
            "client_name": "Rahul Patil",
            "court": "Civil Court, Pune",
            "date": "2026-08-27",
            "time": "11:00",
            "purpose": "Evidence Submission",
            "status": "Scheduled"
        },

        {
            "id": 3,
            "case_number": "LD-2026-003",
            "client_name": "Sneha Joshi",
            "court": "Family Court, Nashik",
            "date": "2026-09-02",
            "time": "12:00",
            "purpose": "Case Discussion",
            "status": "Scheduled"
        }

    ])


    # ========================================================
    # APPOINTMENTS
    # ========================================================

    appointments.clear()

    appointments.extend([

        {
            "id": 1,
            "name": "Priya Sharma",
            "phone": "+91 98765 12345",
            "email": "client@gmail.com",
            "date": "2026-08-20",
            "time": "11:00",
            "service": "Civil Matter",
            "message": "Discussion regarding case.",
            "status": "Pending"
        },

        {
            "id": 2,
            "name": "Rahul Patil",
            "phone": "+91 98765 45678",
            "email": "rahul@gmail.com",
            "date": "2026-08-22",
            "time": "12:00",
            "service": "Property Dispute",
            "message": "Document discussion.",
            "status": "Approved"
        }

    ])


    # ========================================================
    # PAYMENTS
    # ========================================================

    payments.clear()

    payments.extend([

        {
            "id": 1,

            "client_name": "Priya Sharma",

            "case_number": "LD-2026-001",

            "amount": 5000.00,

            "date": "2026-08-05",

            "method": "UPI",

            "status": "Paid",

            "payer": "Priya Sharma",

            "received_by": "Advocate Office",

            "payment_reference": "UPI-PRIYA-001",

            "description":
                "Initial consultation and legal fee."
        },

        {
            "id": 2,

            "client_name": "Rahul Patil",

            "case_number": "LD-2026-002",

            "amount": 7500.00,

            "date": "2026-08-08",

            "method": "Cash",

            "status": "Paid",

            "payer": "Rahul Patil",

            "received_by": "Staff",

            "payment_reference": "CASH-RAHUL-001",

            "description":
                "Case filing fee."
        },

        {
            "id": 3,

            "client_name": "Sneha Joshi",

            "case_number": "LD-2026-003",

            "amount": 3000.00,

            "date": "2026-08-12",

            "method": "UPI",

            "status": "Paid",

            "payer": "Sneha Joshi",

            "received_by": "Advocate Office",

            "payment_reference": "UPI-SNEHA-001",

            "description":
                "Consultation fee."
        }

    ])


    # ========================================================
    # DOCUMENTS
    # ========================================================

    documents.clear()

    documents.extend([

        {
            "id": 1,
            "document_name": "Property Agreement",
            "client_name": "Priya Sharma",
            "case_number": "LD-2026-001",
            "document_type": "Agreement",
            "date": "2026-08-01",
            "description": "Property agreement document.",
            "status": "Available",
            "direction": "Office",
            "sender": "Advocate Office",
            "receiver": "Priya Sharma",
            "file_name": "",
            "file_path": ""
        },

        {
            "id": 2,
            "document_name": "Property Papers",
            "client_name": "Rahul Patil",
            "case_number": "LD-2026-002",
            "document_type": "Property",
            "date": "2026-08-04",
            "description": "Property ownership papers.",
            "status": "Available",
            "direction": "Received",
            "sender": "Rahul Patil",
            "receiver": "Advocate Office",
            "file_name": "",
            "file_path": ""
        },

        {
            "id": 3,
            "document_name": "Family Petition",
            "client_name": "Sneha Joshi",
            "case_number": "LD-2026-003",
            "document_type": "Petition",
            "date": "2026-08-10",
            "description": "Family court petition.",
            "status": "Available",
            "direction": "Office",
            "sender": "Advocate Office",
            "receiver": "Sneha Joshi",
            "file_name": "",
            "file_path": ""
        }

    ])


    # ========================================================
    # COMMUNICATIONS
    # ========================================================

    communications.clear()

    communications.extend([

        {
            "id": 1,
            "client_name": "Priya Sharma",
            "case_number": "LD-2026-001",
            "subject": "Hearing Reminder",
            "message":
                "Your hearing is scheduled for 25 August 2026 at 10:30 AM.",
            "date": "2026-08-18",
            "sender": "Advocate",
            "status": "Sent"
        },

        {
            "id": 2,
            "client_name": "Rahul Patil",
            "case_number": "LD-2026-002",
            "subject": "Document Update",
            "message":
                "Please bring the original property documents.",
            "date": "2026-08-18",
            "sender": "Staff",
            "status": "Sent"
        }

    ])


# Load demo data (used only to seed the database on first run)
load_demo_data()

# ------------------------------------------------------------
# DATABASE WIRING
# ------------------------------------------------------------
# On first run against a fresh MySQL database, the demo data
# above is written in as the starting dataset. On every run
# after that, the real (possibly edited) data already in MySQL
# is loaded instead, so nothing is ever reset or lost on
# restart.
import database as db

db.init_db()

for _table_name, _demo_list in [
    ("clients", clients),
    ("cases", cases),
    ("hearings", hearings),
    ("appointments", appointments),
    ("payments", payments),
    ("documents", documents),
    ("communications", communications),
]:
    db.seed_if_empty(_table_name, _demo_list)
    _loaded = db.load(_table_name)
    _demo_list.clear()
    _demo_list.extend(_loaded)


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def staff_or_advocate_required():

    return session.get(
        "user_role"
    ) in [
        "advocate",
        "staff"
    ]


def advocate_only_required():

    return session.get("user_role") == "advocate"


def client_required():

    return session.get(
        "user_role"
    ) == "client"


# ============================================================
# GET LOGGED-IN CLIENT
# ============================================================

def get_logged_in_client():

    email = session.get(
        "user_email",
        ""
    ).strip().lower()

    if not email:
        return None

    for client in clients:

        client_email = client.get(
            "email",
            ""
        ).strip().lower()

        if client_email == email:

            return client

    return None


# ============================================================
# CLIENT CASES
# ============================================================

def get_client_cases(client_name):

    if not client_name:
        return []

    client_name = client_name.strip().lower()

    return [

        case
        for case in cases

        if case.get(
            "client_name",
            ""
        ).strip().lower() == client_name

    ]


# ============================================================
# CLIENT HEARINGS
# ============================================================

def get_client_hearings(client_name):

    if not client_name:
        return []

    client_name = client_name.strip().lower()

    return [

        hearing
        for hearing in hearings

        if hearing.get(
            "client_name",
            ""
        ).strip().lower() == client_name

    ]


# ============================================================
# CLIENT APPOINTMENTS
# ============================================================

def get_client_appointments(email):

    if not email:
        return []

    email = email.strip().lower()

    return [

        appointment
        for appointment in appointments

        if appointment.get(
            "email",
            ""
        ).strip().lower() == email

    ]


# ============================================================
# CLIENT PAYMENTS
# ============================================================

def get_client_payments(client_name):

    if not client_name:
        return []

    client_name = client_name.strip().lower()

    return [

        payment
        for payment in payments

        if payment.get(
            "client_name",
            ""
        ).strip().lower() == client_name

    ]


# ============================================================
# CLIENT DOCUMENTS
# ============================================================

def get_client_documents(client_name):

    if not client_name:
        return []

    client_name = client_name.strip().lower()

    return [

        document
        for document in documents

        if document.get(
            "client_name",
            ""
        ).strip().lower() == client_name

    ]


# ============================================================
# CLIENT COMMUNICATION
# ============================================================

def get_client_communications(client_name):

    if not client_name:
        return []

    client_name = client_name.strip().lower()

    return [

        communication
        for communication in communications

        if communication.get(
            "client_name",
            ""
        ).strip().lower() == client_name

    ]


# ============================================================
# CALCULATE PAYMENT TOTAL
# ============================================================

def calculate_total_payments(payment_list):

    total = 0.0

    for payment in payment_list:

        try:

            total += float(
                payment.get(
                    "amount",
                    0
                )
            )

        except (
            ValueError,
            TypeError
        ):

            pass

    return total


# ============================================================
# HEARING DEADLINE REMINDERS
# ============================================================

def hearing_days_remaining(hearing_date_str):
    """
    Returns the number of days between today and a hearing's
    date (negative if it's already passed), or None if the
    date can't be parsed. Registered as a Jinja global below so
    any template can flag hearings coming up soon.
    """

    try:
        hearing_date = datetime.strptime(
            str(hearing_date_str), "%Y-%m-%d"
        ).date()
        return (hearing_date - date.today()).days
    except (ValueError, TypeError):
        return None


app.jinja_env.globals["hearing_days_remaining"] = hearing_days_remaining


# ============================================================
# NEXT ID
# ============================================================

def get_next_id(data_list):

    if not data_list:
        return 1

    ids = []

    for item in data_list:

        try:

            ids.append(
                int(
                    item.get(
                        "id",
                        0
                    )
                )
            )

        except (
            ValueError,
            TypeError
        ):

            pass

    if not ids:
        return 1

    return max(ids) + 1


# ============================================================
# AUDIT / ACTIVITY LOG
# ============================================================

audit_log = []


def log_activity(actor, action, details=""):
    """
    Record an entry in the office's activity log. Called
    whenever someone views, adds, edits, signs, or otherwise
    changes something worth tracking.
    """

    entry = {
        "id": get_next_id(audit_log),
        "actor": actor or "Unknown",
        "action": action,
        "details": details,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }

    audit_log.append(entry)
    db.save("audit_log", audit_log)


# ============================================================
# CONFLICT OF INTEREST CHECK
# ============================================================

import difflib
import re

CONFLICT_MATCH_THRESHOLD = 0.82  # 0.0-1.0; higher = stricter


def _normalize_name(raw_name):
    """
    Lowercases a name, strips common titles/honorifics and
    punctuation, and collapses extra whitespace — so "Adv. Priya
    S. Sharma" and "priya sharma" are recognized as close.
    """

    name = (raw_name or "").strip().lower()
    name = re.sub(r"[.,]", " ", name)

    titles = [
        "mr", "mrs", "ms", "miss", "dr", "adv", "advocate", "shri", "smt"
    ]

    words = [w for w in name.split() if w not in titles]

    return " ".join(words)


def check_conflict_of_interest(opposing_party_name):
    """
    Checks a proposed opposing party's name against every
    existing client using normalized text plus fuzzy similarity,
    so close variants (titles, middle initials, minor typos)
    are still caught, not just exact matches.

    Returns a dict {"client": <matched client>, "score": 0.0-1.0,
    "exact": bool} for the best match at or above the threshold,
    or None if nothing matches closely enough.
    """

    normalized_input = _normalize_name(opposing_party_name)

    if not normalized_input:
        return None

    best_match = None
    best_score = 0.0

    for c in clients:

        normalized_client = _normalize_name(c.get("name", ""))

        if not normalized_client:
            continue

        if normalized_client == normalized_input:
            return {"client": c, "score": 1.0, "exact": True}

        score = difflib.SequenceMatcher(
            None, normalized_input, normalized_client
        ).ratio()

        if score > best_score:
            best_score = score
            best_match = c

    if best_match and best_score >= CONFLICT_MATCH_THRESHOLD:
        return {"client": best_match, "score": best_score, "exact": False}

    return None


# ============================================================
# ALLOWED FILE
# ============================================================

def allowed_file(filename):

    if not filename:
        return False

    return (

        "." in filename

        and

        filename.rsplit(
            ".",
            1
        )[1].lower()

        in ALLOWED_EXTENSIONS

    )


# ============================================================
# HOME
# ============================================================

@app.route("/")
def home():

    return render_template(
        "index.html",
        office_name=OFFICE_NAME,
        office_hours_text=office_hours_text
    )


# ============================================================
# ABOUT
# ============================================================

@app.route("/about")
def about():

    return render_template(
        "about.html",
        office_name=OFFICE_NAME
    )


# ============================================================
# SERVICES
# ============================================================

@app.route("/services")
def services():

    return render_template(
        "services.html",
        office_name=OFFICE_NAME
    )


# ============================================================
# CONTACT
# ============================================================

@app.route("/contact")
def contact():

    return render_template(
        "contact.html",
        office_name=OFFICE_NAME,
        office_hours_text=office_hours_text
    )


# ============================================================
# APPOINTMENT
# ============================================================

@app.route(
    "/appointment",
    methods=["GET", "POST"]
)
def appointment():

    if request.method == "POST":

        appointment_data = {

            "id":
                get_next_id(appointments),

            "name":
                request.form.get(
                    "name",
                    ""
                ).strip(),

            "phone":
                request.form.get(
                    "phone",
                    ""
                ).strip(),

            "email":
                request.form.get(
                    "email",
                    ""
                ).strip().lower(),

            "date":
                request.form.get(
                    "date",
                    ""
                ),

            "time":
                request.form.get(
                    "time",
                    ""
                ),

            "service":
                request.form.get(
                    "service",
                    ""
                ).strip(),

            "message":
                request.form.get(
                    "message",
                    ""
                ).strip(),

            "opposing_party":
                request.form.get(
                    "opposing_party",
                    ""
                ).strip(),

            "status":
                "Pending"
        }

        conflict_match = check_conflict_of_interest(
            appointment_data["opposing_party"]
        )

        appointment_data["conflict_flag"] = bool(conflict_match)

        appointment_data["conflict_score"] = (
            round(conflict_match["score"] * 100)
            if conflict_match else 0
        )

        appointments.append(
            appointment_data
        )
        db.save("appointments", appointments)

        if conflict_match:

            matched_name = conflict_match["client"].get("name", "")
            match_kind = (
                "exact match" if conflict_match["exact"]
                else f"{round(conflict_match['score'] * 100)}% similar"
            )

            log_activity(
                "System",
                "Conflict of Interest Flagged",
                f"New appointment request names '{appointment_data['opposing_party']}' "
                f"as opposing party — {match_kind} to existing client {matched_name}"
            )

        return redirect(
            url_for(
                "appointment_success",
                appointment_id=
                    appointment_data["id"]
            )
        )

    return render_template(
        "appointment.html",
        office_name=OFFICE_NAME
    )


# ============================================================
# APPOINTMENT SUCCESS
# ============================================================

@app.route(
    "/appointment/success/<int:appointment_id>"
)
def appointment_success(appointment_id):

    appointment_data = None

    for item in appointments:

        if item.get(
            "id"
        ) == appointment_id:

            appointment_data = item

            break

    if appointment_data is None:

        return redirect(
            url_for("appointment")
        )

    return render_template_string(

        """
        <!DOCTYPE html>

        <html lang="en">

        <head>

            <meta charset="UTF-8">

            <meta name="viewport"
                  content="width=device-width, initial-scale=1.0">

            <title>
                Appointment Submitted | {{ office_name }}
            </title>

            <style>

                * {
                    box-sizing: border-box;
                }

                body {
                    margin: 0;
                    font-family: Arial, sans-serif;
                    background: #f5f7fb;
                    color: #222;
                }

                .success-container {
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 30px;
                }

                .success-card {
                    width: 100%;
                    max-width: 650px;
                    background: white;
                    border-radius: 18px;
                    padding: 45px;
                    text-align: center;
                    box-shadow: 0 10px 35px rgba(0,0,0,0.10);
                }

                .success-icon {
                    width: 80px;
                    height: 80px;
                    margin: 0 auto 20px;
                    border-radius: 50%;
                    background: #e9f8ef;
                    color: #198754;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 42px;
                    font-weight: bold;
                }

                h1 {
                    margin-bottom: 10px;
                    color: #17324d;
                }

                .subtitle {
                    color: #666;
                    margin-bottom: 30px;
                }

                .appointment-details {
                    text-align: left;
                    background: #f8fafc;
                    border-radius: 12px;
                    padding: 20px;
                    margin-bottom: 30px;
                }

                .detail {
                    display: flex;
                    justify-content: space-between;
                    gap: 20px;
                    padding: 10px 0;
                    border-bottom: 1px solid #e5e7eb;
                }

                .detail:last-child {
                    border-bottom: none;
                }

                .detail strong {
                    color: #555;
                }

                .detail span {
                    text-align: right;
                }

                .buttons {
                    display: flex;
                    justify-content: center;
                    gap: 12px;
                    flex-wrap: wrap;
                }

                .btn {
                    display: inline-block;
                    padding: 12px 22px;
                    border-radius: 8px;
                    text-decoration: none;
                    font-weight: 600;
                }

                .primary {
                    background: #17324d;
                    color: white;
                }

                .secondary {
                    border: 1px solid #17324d;
                    color: #17324d;
                    background: white;
                }

            </style>

        </head>

        <body>

            <div class="success-container">

                <div class="success-card">

                    <div class="success-icon">
                        ✓
                    </div>

                    <h1>
                        Appointment Submitted
                    </h1>

                    <p class="subtitle">
                        Your appointment request has been
                        successfully submitted to
                        {{ office_name }}.
                    </p>

                    <div class="appointment-details">

                        <div class="detail">

                            <strong>
                                Name
                            </strong>

                            <span>
                                {{ appointment.name }}
                            </span>

                        </div>

                        <div class="detail">

                            <strong>
                                Phone
                            </strong>

                            <span>
                                {{ appointment.phone }}
                            </span>

                        </div>

                        <div class="detail">

                            <strong>
                                Date
                            </strong>

                            <span>
                                {{ appointment.date }}
                            </span>

                        </div>

                        <div class="detail">

                            <strong>
                                Time
                            </strong>

                            <span>
                                {{ appointment.time }}
                            </span>

                        </div>

                        <div class="detail">

                            <strong>
                                Service
                            </strong>

                            <span>
                                {{ appointment.service }}
                            </span>

                        </div>

                        <div class="detail">

                            <strong>
                                Status
                            </strong>

                            <span>
                                {{ appointment.status }}
                            </span>

                        </div>

                    </div>

                    <div class="buttons">

                        <a href="{{ url_for('home') }}"
                           class="btn primary">
                            Back to Home
                        </a>

                        <a href="{{ url_for('appointment') }}"
                           class="btn secondary">
                            Book Another Appointment
                        </a>

                    </div>

                </div>

            </div>

        </body>

        </html>
        """,

        office_name=OFFICE_NAME,

        appointment=appointment_data
    )


# ============================================================
# FORGOT PASSWORD
# ============================================================

@app.route(
    "/forgot-password",
    methods=["GET", "POST"]
)
def forgot_password():

    if request.method == "POST":

        email = request.form.get("email", "").strip().lower()
        role = request.form.get("user_role", "").strip().lower()

        account_found = False

        if role == "advocate" and email == ADVOCATE_EMAIL:
            account_found = True

        elif role == "staff" and email == STAFF_EMAIL:
            account_found = True

        elif role == "client":
            account_found = any(
                c.get("email", "").strip().lower() == email
                for c in clients
            )

        elif role == "intern":
            account_found = any(
                i.get("email", "").strip().lower() == email
                for i in interns
            )

        reset_link = None

        if account_found:

            token = secrets.token_urlsafe(24)

            password_reset_tokens[token] = {
                "email": email,
                "role": role,
                "expires": datetime.now().timestamp() + 3600,
            }

            reset_link = url_for(
                "reset_password", token=token, _external=False
            )

        return render_template(

            "forgot_password.html",

            office_name=OFFICE_NAME,

            account_found=account_found,

            reset_link=reset_link

        )

    return render_template(

        "forgot_password.html",

        office_name=OFFICE_NAME

    )


@app.route(
    "/reset-password/<token>",
    methods=["GET", "POST"]
)
def reset_password(token):

    token_data = password_reset_tokens.get(token)

    if not token_data or token_data["expires"] < datetime.now().timestamp():

        return render_template(

            "reset_password.html",

            office_name=OFFICE_NAME,

            invalid=True

        )

    if request.method == "POST":

        new_password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not new_password or new_password != confirm_password:

            return render_template(

                "reset_password.html",

                office_name=OFFICE_NAME,

                error="Passwords do not match."

            )

        email = token_data["email"]
        role = token_data["role"]

        if role == "advocate":

            global ADVOCATE_PASSWORD_HASH
            ADVOCATE_PASSWORD_HASH = generate_password_hash(new_password)

        elif role == "staff":

            global STAFF_PASSWORD_HASH
            STAFF_PASSWORD_HASH = generate_password_hash(new_password)

        elif role == "client":

            for c in clients:
                if c.get("email", "").strip().lower() == email:
                    c["password"] = generate_password_hash(new_password)
                    break

            db.save("clients", clients)

        elif role == "intern":

            for i in interns:
                if i.get("email", "").strip().lower() == email:
                    i["password"] = generate_password_hash(new_password)
                    break

            db.save("interns", interns)

        del password_reset_tokens[token]

        log_activity(email, "Password Reset", f"Role: {role}")

        return redirect(url_for("login"))

    return render_template(

        "reset_password.html",

        office_name=OFFICE_NAME

    )


# ============================================================
# LOGIN
# ============================================================

@app.route(
    "/login",
    methods=["GET", "POST"]
)
def login():

    if request.method == "POST":

        email = request.form.get(
            "email",
            ""
        ).strip().lower()

        password = request.form.get(
            "password",
            ""
        )

        role = request.form.get(
            "user_role",
            ""
        ).strip().lower()


        if (
            not email
            or not password
            or not role
        ):

            return render_template(

                "login.html",

                office_name=OFFICE_NAME,

                error=
                    "Please select account type "
                    "and enter email and password."
            )


        # ====================================================
        # ADVOCATE LOGIN
        # ====================================================

        if role == "advocate":

            if (
                email == ADVOCATE_EMAIL
                and check_password_hash(ADVOCATE_PASSWORD_HASH, password)
            ):

                session.clear()

                session["user_role"] = "advocate"

                session["user_email"] = email

                log_activity(email, "Login", "Advocate logged in")

                return redirect(
                    url_for(
                        "advocate_dashboard"
                    )
                )


        # ====================================================
        # STAFF LOGIN
        # ====================================================

        elif role == "staff":

            if (
                email == STAFF_EMAIL
                and check_password_hash(STAFF_PASSWORD_HASH, password)
            ):

                session.clear()

                session["user_role"] = "staff"

                session["user_email"] = email

                log_activity(email, "Login", "Staff logged in")

                return redirect(
                    url_for(
                        "staff_dashboard"
                    )
                )


        # ====================================================
        # CLIENT LOGIN
        # ====================================================

        elif role == "client":

            for client in clients:

                client_email = client.get(
                    "email",
                    ""
                ).strip().lower()

                client_password = str(
                    client.get(
                        "password",
                        ""
                    )
                )

                if (
                    client_email == email
                    and _safe_check_password(client_password, password)
                ):

                    session.clear()

                    session["user_role"] = "client"

                    session["user_email"] = client_email

                    session["client_id"] = client.get(
                        "id"
                    )

                    log_activity(
                        client.get("name", client_email),
                        "Login",
                        "Client logged in"
                    )

                    return redirect(
                        url_for(
                            "client_dashboard"
                        )
                    )


        # ====================================================
        # INTERN LOGIN
        # ====================================================

        elif role == "intern":

            for intern in interns:

                intern_email = intern.get(
                    "email", ""
                ).strip().lower()

                intern_password = str(
                    intern.get("password", "")
                )

                if (
                    intern_email == email
                    and _safe_check_password(intern_password, password)
                ):

                    session.clear()

                    session["user_role"] = "intern"

                    session["user_email"] = intern_email

                    log_activity(
                        intern.get("full_name", intern_email),
                        "Login",
                        "Intern logged in"
                    )

                    return redirect(
                        url_for("intern_dashboard")
                    )


        return render_template(

            "login.html",

            office_name=OFFICE_NAME,

            error=
                "Invalid email, password or account type."
        )


    return render_template(

        "login.html",

        office_name=OFFICE_NAME
    )


# ============================================================
# CLIENT REGISTRATION
# ============================================================

@app.route(
    "/register",
    methods=["GET", "POST"]
)
def register():

    if request.method == "POST":

        name = request.form.get(
            "name",
            ""
        ).strip()

        email = request.form.get(
            "email",
            ""
        ).strip().lower()

        phone = request.form.get(
            "phone",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        )

        confirm_password = request.form.get(
            "confirm_password",
            ""
        )


        if (
            not name
            or not email
            or not phone
            or not password
        ):

            return render_template(

                "register.html",

                office_name=OFFICE_NAME,

                error=
                    "Please fill in all required fields."
            )


        if len(password) < 6:

            return render_template(

                "register.html",

                office_name=OFFICE_NAME,

                error=
                    "Password must be at least 6 characters."
            )


        if password != confirm_password:

            return render_template(

                "register.html",

                office_name=OFFICE_NAME,

                error=
                    "Passwords do not match."
            )


        for existing_client in clients:

            existing_email = existing_client.get(
                "email",
                ""
            ).strip().lower()

            if existing_email == email:

                return render_template(

                    "register.html",

                    office_name=OFFICE_NAME,

                    error=
                        "An account with this email already exists."
                )


        new_client = {

            "id":
                get_next_id(clients),

            "name":
                name,

            "phone":
                phone,

            "email":
                email,

            "password":
                generate_password_hash(password),

            "address":
                "",

            "case_type":
                "Legal Matter",

            "status":
                "Active"
        }


        clients.append(
            new_client
        )
        db.save("clients", clients)


        return render_template(

            "registration_success.html",

            office_name=OFFICE_NAME,

            client=new_client
        )


    return render_template(

        "register.html",

        office_name=OFFICE_NAME
    )


@app.route(
    "/search"
)
def global_search():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    query = request.args.get("q", "").strip().lower()

    matched_clients = []
    matched_cases = []
    matched_hearings = []

    if query:

        matched_clients = [
            c for c in clients
            if query in c.get("name", "").lower()
            or query in c.get("email", "").lower()
            or query in c.get("phone", "").lower()
        ]

        matched_cases = [
            c for c in cases
            if query in c.get("case_number", "").lower()
            or query in c.get("client_name", "").lower()
            or query in c.get("case_type", "").lower()
        ]

        matched_hearings = [
            h for h in hearings
            if query in h.get("client_name", "").lower()
            or query in h.get("case_number", "").lower()
            or query in h.get("court", "").lower()
        ]

    return render_template(

        "search_results.html",

        office_name=OFFICE_NAME,

        query=query,

        matched_clients=matched_clients,

        matched_cases=matched_cases,

        matched_hearings=matched_hearings

    )


# ============================================================
# ADVOCATE DASHBOARD
# ============================================================

@app.route("/advocate/dashboard")
def advocate_dashboard():

    if session.get(
        "user_role"
    ) != "advocate":

        return redirect(
            url_for("login")
        )


    today = date.today().isoformat()


    today_hearing_list = [

        hearing
        for hearing in hearings

        if hearing.get(
            "date"
        ) == today
    ]


    pending_appointments = [

        appointment
        for appointment in appointments

        if appointment.get(
            "status"
        ) == "Pending"
    ]


    active_cases = [

        case
        for case in cases

        if case.get(
            "status"
        ) == "Active"
    ]


    upcoming_hearings = [

        hearing
        for hearing in hearings

        if hearing.get("status", "").lower() == "scheduled"
        and hearing_days_remaining(hearing.get("date")) is not None
        and 0 <= hearing_days_remaining(hearing.get("date")) <= 7
    ]


    unread_messages = [
        c for c in communications
        if c.get("status") == "Unread"
    ]


    notifications = (
        [
            {
                "text": f"New message: {m.get('subject', '')} ({m.get('client_name') or m.get('sender', '')})",
                "url": url_for("office_communication"),
            }
            for m in unread_messages[-5:]
        ]
        + [
            {
                "text": f"⚠ Possible conflict of interest — {a.get('name', '')}",
                "url": url_for("appointments_page"),
            }
            for a in appointments
            if a.get("conflict_flag")
        ]
        + [
            {
                "text": f"Pending appointment request from {a.get('name', '')}",
                "url": url_for("appointments_page"),
            }
            for a in pending_appointments[-5:]
        ]
    )


    total_payment_amount = calculate_total_payments(
        payments
    )


    return render_template(

        "advocate_dashboard.html",

        office_name=OFFICE_NAME,

        email=session.get(
            "user_email"
        ),

        total_clients=len(
            clients
        ),

        active_cases=len(
            active_cases
        ),

        today_hearings=len(
            today_hearing_list
        ),

        upcoming_hearings=
            upcoming_hearings,

        pending_appointments=len(
            pending_appointments
        ),

        recent_clients=clients[-5:],

        recent_cases=cases[-5:],

        notifications=
            notifications,

        today_hearing_list=
            today_hearing_list,

        today=today,

        total_payments=len(
            payments
        ),

        total_payment_amount=
            total_payment_amount,

        total_documents=len(
            documents
        ),

        appointments=appointments[-5:],

        communications=communications[-5:]

    )


# ============================================================
# STAFF DASHBOARD
# ============================================================

@app.route("/staff/dashboard")
def staff_dashboard():

    if session.get(
        "user_role"
    ) != "staff":

        return redirect(
            url_for("login")
        )


    today = date.today().isoformat()


    today_appointments_list = [

        appointment
        for appointment in appointments

        if appointment.get(
            "date"
        ) == today
    ]


    pending_requests = [

        appointment
        for appointment in appointments

        if appointment.get(
            "status"
        ) == "Pending"
    ]


    active_cases = [

        case
        for case in cases

        if case.get(
            "status"
        ) == "Active"
    ]


    today_hearing_list = [

        hearing
        for hearing in hearings

        if hearing.get(
            "date"
        ) == today
    ]


    unread_messages = [
        c for c in communications
        if c.get("status") == "Unread"
    ]


    notifications = (
        [
            {
                "text": f"New message: {m.get('subject', '')} ({m.get('client_name') or m.get('sender', '')})",
                "url": url_for("office_communication"),
            }
            for m in unread_messages[-5:]
        ]
        + [
            {
                "text": f"⚠ Possible conflict of interest — {a.get('name', '')}",
                "url": url_for("appointments_page"),
            }
            for a in appointments
            if a.get("conflict_flag")
        ]
        + [
            {
                "text": f"Pending appointment request from {a.get('name', '')}",
                "url": url_for("appointments_page"),
            }
            for a in pending_requests[-5:]
        ]
    )


    total_payment_amount = calculate_total_payments(
        payments
    )


    return render_template(

        "staff_dashboard.html",

        office_name=OFFICE_NAME,

        notifications=
            notifications,

        email=session.get(
            "user_email"
        ),

        total_clients=len(
            clients
        ),

        active_cases=len(
            active_cases
        ),

        today_appointments=len(
            today_appointments_list
        ),

        pending_requests=len(
            pending_requests
        ),

        recent_clients=clients[-5:],

        today_appointments_list=
            today_appointments_list,

        today=today,

        total_payments=len(
            payments
        ),

        total_payment_amount=
            total_payment_amount,

        total_documents=len(
            documents
        ),

        appointments=appointments[-5:],

        recent_cases=cases[-5:],

        today_hearing_list=
            today_hearing_list,

        communications=communications[-5:]

    )


# ============================================================
# OFFICE COMMUNICATION
# ============================================================

@app.route(
    "/office/communication",
    methods=["GET", "POST"],
    endpoint="office_communication"
)
def office_communication():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        recipient = request.form.get(
            "recipient",
            ""
        ).strip()

        recipient_client_name = ""

        if recipient.startswith("client:"):
            recipient_client_name = recipient.split(":", 1)[1].strip()

        communication = {

            "id":
                get_next_id(communications),

            "client_name":
                recipient_client_name or request.form.get(
                    "client_name",
                    ""
                ).strip(),

            "case_number":
                request.form.get(
                    "case_number",
                    ""
                ).strip(),

            "subject":
                request.form.get(
                    "subject",
                    ""
                ).strip(),

            "message":
                request.form.get(
                    "message",
                    ""
                ).strip(),

            "date":
                date.today().isoformat(),

            "sender":
                session.get(
                    "user_role",
                    "staff"
                ).title(),

            "status":
                "Sent"
        }


        communications.append(
            communication
        )
        db.save("communications", communications)


        return redirect(
            url_for(
                "office_communication"
            )
        )


    return render_template(

        "office_communication.html",

        office_name=OFFICE_NAME,

        communications=communications,

        clients=clients,

        cases=cases,

        preselect_client=
            request.args.get("client", "")

    )


# ============================================================
# COMMUNICATION COMPATIBILITY ROUTES
# ============================================================

@app.route(
    "/office-communication"
)
def office_communication_compat():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    return redirect(
        url_for("office_communication")
    )


@app.route(
    "/communication"
)
def communication_compat():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    return redirect(
        url_for("office_communication")
    )


# ============================================================
# CLIENT DASHBOARD
# ============================================================

@app.route(
    "/client/dashboard"
)
def client_dashboard():

    if not client_required():

        return redirect(
            url_for("login")
        )


    client = get_logged_in_client()


    if client is None:

        session.clear()

        return redirect(
            url_for("login")
        )


    client_name = client.get(
        "name",
        ""
    )

    client_email = client.get(
        "email",
        ""
    )


    # ========================================================
    # CLIENT-SPECIFIC DATA
    # ========================================================

    client_cases_list = get_client_cases(
        client_name
    )

    client_hearings_list = get_client_hearings(
        client_name
    )

    client_appointments_list = get_client_appointments(
        client_email
    )

    client_payments_list = get_client_payments(
        client_name
    )

    client_documents_list = get_client_documents(
        client_name
    )

    client_communications_list = (
        get_client_communications(
            client_name
        )
    )


    # ========================================================
    # PAYMENT TOTAL
    # ========================================================

    total_payment_amount = calculate_total_payments(
        client_payments_list
    )


    return render_template(

        "client_dashboard.html",

        office_name=OFFICE_NAME,

        email=client_email,

        client=client,

        client_cases=
            client_cases_list,

        client_hearings=
            client_hearings_list,

        client_appointments=
            client_appointments_list,

        client_payments=
            client_payments_list,

        client_documents=
            client_documents_list,

        client_communications=
            client_communications_list,

        total_cases=len(
            client_cases_list
        ),

        total_hearings=len(
            client_hearings_list
        ),

        total_appointments=len(
            client_appointments_list
        ),

        total_payments=len(
            client_payments_list
        ),

        total_documents=len(
            client_documents_list
        ),

        total_communications=len(
            client_communications_list
        ),

        total_payment_amount=
            total_payment_amount,

        today=
            date.today().isoformat()

    )


# ============================================================
# CLIENT CASES
# ============================================================

@app.route(
    "/client/cases"
)
def client_cases():

    if not client_required():

        return redirect(
            url_for("login")
        )


    client = get_logged_in_client()


    if client is None:

        return redirect(
            url_for("login")
        )


    client_cases_list = get_client_cases(
        client.get(
            "name",
            ""
        )
    )


    return render_template(

        "client_cases.html",

        office_name=OFFICE_NAME,

        client=client,

        cases=client_cases_list,

        client_cases=
            client_cases_list

    )


@app.route(
    "/client/case"
)
def client_case_page():

    return redirect(
        url_for("client_cases")
    )


# ============================================================
# CLIENT HEARINGS
# ============================================================

@app.route(
    "/client/hearings"
)
def client_hearings():

    if not client_required():

        return redirect(
            url_for("login")
        )


    client = get_logged_in_client()


    if client is None:

        return redirect(
            url_for("login")
        )


    client_hearings_list = get_client_hearings(
        client.get(
            "name",
            ""
        )
    )


    return render_template(

        "client_hearings.html",

        office_name=OFFICE_NAME,

        client=client,

        hearings=client_hearings_list,

        client_hearings=
            client_hearings_list

    )


@app.route(
    "/client/hearing"
)
def client_hearing_page():

    return redirect(
        url_for("client_hearings")
    )


# ============================================================
# CLIENT APPOINTMENTS
# ============================================================

@app.route(
    "/client/appointments"
)
def client_appointments():

    if not client_required():

        return redirect(
            url_for("login")
        )


    client = get_logged_in_client()


    if client is None:

        return redirect(
            url_for("login")
        )


    client_appointments_list = (
        get_client_appointments(
            client.get(
                "email",
                ""
            )
        )
    )


    return render_template(

        "client_appointments.html",

        office_name=OFFICE_NAME,

        client=client,

        client_appointments=
            client_appointments_list,

        appointments=
            client_appointments_list

    )


@app.route(
    "/client/appointment"
)
def client_appointment_page():

    return redirect(
        url_for("client_appointments")
    )


# ============================================================
# CLIENT PAYMENTS
# ============================================================

@app.route(
    "/client/payments"
)
def client_payments():

    # --------------------------------------------------------
    # ONLY CLIENT CAN ACCESS
    # --------------------------------------------------------

    if not client_required():

        return redirect(
            url_for("login")
        )


    # --------------------------------------------------------
    # GET LOGGED-IN CLIENT
    # --------------------------------------------------------

    client = get_logged_in_client()


    if client is None:

        session.clear()

        return redirect(
            url_for("login")
        )


    # --------------------------------------------------------
    # GET CLIENT NAME
    # --------------------------------------------------------

    client_name = client.get(
        "name",
        ""
    )


    # --------------------------------------------------------
    # IMPORTANT:
    # ONLY THIS CLIENT'S PAYMENTS ARE RETURNED
    # --------------------------------------------------------

    client_payments_list = get_client_payments(
        client_name
    )


    # --------------------------------------------------------
    # TOTAL PAYMENT
    # --------------------------------------------------------

    total_amount = calculate_total_payments(
        client_payments_list
    )


    # --------------------------------------------------------
    # BILLING SUMMARY (total billed vs paid vs due)
    # --------------------------------------------------------

    client_cases_list = get_client_cases(client_name)

    total_billed = sum(
        float(c.get("fee_amount", 0) or 0) for c in client_cases_list
    )

    total_paid = sum(
        float(p.get("amount", 0) or 0)
        for p in client_payments_list
        if p.get("status") == "Paid"
    )

    total_due = max(total_billed - total_paid, 0)


    # --------------------------------------------------------
    # CLIENT PAYMENT PAGE
    # --------------------------------------------------------

    return render_template(

        "client_payments.html",

        office_name=OFFICE_NAME,

        total_billed=
            total_billed,

        total_paid=
            total_paid,

        total_due=
            total_due,

        client=client,

        payments=
            client_payments_list,

        client_payments=
            client_payments_list,

        total_amount=
            total_amount,

        total_payment_amount=
            total_amount,

        payment_count=
            len(client_payments_list),

        today=
            date.today().isoformat()

    )


@app.route(
    "/client/payment"
)
def client_payment_page():

    return redirect(
        url_for("client_payments")
    )


# ============================================================
# DOCUMENT GENERATOR
# ============================================================

DOCUMENT_TEMPLATES = {
    "nda": {
        "title": "Non-Disclosure Agreement",
        "body": (
            "This Non-Disclosure Agreement (\"Agreement\") is entered into as of {date} "
            "between {office_name}, located at 123 Court Road, Sinnar, Nashik, Maharashtra "
            "(\"Disclosing Party\"), and {full_name} (\"Receiving Party\").\n\n"
            "1. CONFIDENTIAL INFORMATION. The Receiving Party agrees to hold in strict "
            "confidence all information disclosed in connection with {case_reference}, "
            "and shall not disclose such information to any third party without prior "
            "written consent.\n\n"
            "2. TERM. This Agreement shall remain in effect for a period of two (2) years "
            "from the date first written above.\n\n"
            "3. GOVERNING LAW. This Agreement shall be governed by the laws applicable in "
            "Maharashtra, India.\n\n"
            "IN WITNESS WHEREOF, the parties have executed this Agreement as of the date "
            "first written above."
        ),
    },
    "retainer": {
        "title": "Retainer Agreement",
        "body": (
            "This Retainer Agreement (\"Agreement\") is made as of {date} between "
            "{office_name} (\"Advocate\") and {full_name} (\"Client\"), for legal "
            "representation in connection with {case_reference}.\n\n"
            "1. SCOPE OF SERVICES. The Advocate agrees to provide legal representation "
            "and advice to the Client regarding the above matter.\n\n"
            "2. FEES. The Client agrees to pay the Advocate's fees as separately agreed, "
            "payable upon receipt of invoice.\n\n"
            "3. TERMINATION. Either party may terminate this engagement with written "
            "notice, subject to payment for services already rendered.\n\n"
            "IN WITNESS WHEREOF, the parties have executed this Agreement as of the date "
            "first written above."
        ),
    },
}


@app.route(
    "/client/documents/generate",
    methods=["GET", "POST"]
)
def generate_document():

    if not client_required():

        return redirect(
            url_for("login")
        )

    client = get_logged_in_client()

    if client is None:

        return redirect(
            url_for("login")
        )

    if request.method == "POST":

        doc_type = request.form.get("doc_type", "nda")
        case_reference = request.form.get(
            "case_reference", ""
        ).strip() or "the matter between the parties"

        template = DOCUMENT_TEMPLATES.get(doc_type, DOCUMENT_TEMPLATES["nda"])

        generated_text = template["body"].format(
            date=date.today().strftime("%d %B %Y"),
            office_name=OFFICE_NAME,
            full_name=client.get("name", ""),
            case_reference=case_reference,
        )

        log_activity(
            client.get("name", ""),
            "Generated Document",
            template["title"]
        )

        return render_template(

            "generated_document.html",

            office_name=OFFICE_NAME,

            doc_title=template["title"],

            client_name=client.get("name", ""),

            generated_text=generated_text,

            generated_date=date.today().strftime("%d %B %Y")

        )

    return render_template(

        "generate_document.html",

        office_name=OFFICE_NAME,

        client=client

    )


# ============================================================
# CLIENT DOCUMENTS
# ============================================================

@app.route(
    "/client/documents"
)
def client_documents():

    if not client_required():

        return redirect(
            url_for("login")
        )


    client = get_logged_in_client()


    if client is None:

        return redirect(
            url_for("login")
        )


    client_documents_list = get_client_documents(
        client.get(
            "name",
            ""
        )
    )


    return render_template(

        "client_documents.html",

        office_name=OFFICE_NAME,

        client=client,

        client_documents=
            client_documents_list,

        documents=
            client_documents_list

    )


# ============================================================
# CLIENT DOCUMENT UPLOAD
# ============================================================

@app.route(
    "/client/documents/upload",
    methods=["GET", "POST"]
)
def client_upload_document():

    if not client_required():

        return redirect(
            url_for("login")
        )


    client = get_logged_in_client()


    if client is None:

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        document_name = request.form.get(
            "document_name",
            ""
        ).strip()

        case_number = request.form.get(
            "case_number",
            ""
        ).strip()

        document_type = request.form.get(
            "document_type",
            ""
        ).strip()

        description = request.form.get(
            "description",
            ""
        ).strip()

        uploaded_file = request.files.get(
            "document_file"
        )


        if not document_name:

            return render_template(

                "client_documents.html",

                office_name=OFFICE_NAME,

                client=client,

                documents=get_client_documents(
                    client.get(
                        "name",
                        ""
                    )
                ),

                error=
                    "Please enter a document name."
            )


        file_name = ""

        file_path = ""


        if (
            uploaded_file
            and uploaded_file.filename
        ):

            if not allowed_file(
                uploaded_file.filename
            ):

                return render_template(

                    "client_documents.html",

                    office_name=OFFICE_NAME,

                    client=client,

                    documents=get_client_documents(
                        client.get(
                            "name",
                            ""
                        )
                    ),

                    error=
                        "File type is not allowed."
                )


            original_name = secure_filename(
                uploaded_file.filename
            )


            unique_name = (

                str(
                    get_next_id(documents)
                )

                + "_"

                + original_name

            )


            save_path = os.path.join(

                app.config[
                    "UPLOAD_FOLDER"
                ],

                unique_name

            )


            uploaded_file.save(
                save_path
            )


            file_name = original_name

            file_path = (
                "uploads/"
                + unique_name
            )


        document = {

            "id":
                get_next_id(documents),

            "document_name":
                document_name,

            "client_name":
                client.get(
                    "name",
                    ""
                ),

            "case_number":
                case_number,

            "document_type":
                document_type,

            "date":
                date.today().isoformat(),

            "description":
                description,

            "status":
                "Received",

            "signature_status":
                "Not Required",

            "direction":
                "Received",

            "sender":
                client.get(
                    "name",
                    ""
                ),

            "receiver":
                "Advocate Office",

            "file_name":
                file_name,

            "file_path":
                file_path
        }


        documents.append(
            document
        )
        db.save("documents", documents)


        return redirect(
            url_for(
                "client_documents"
            )
        )


    return render_template(

        "client_documents.html",

        office_name=OFFICE_NAME,

        client=client,

        documents=get_client_documents(
            client.get(
                "name",
                ""
            )
        )

    )


# ============================================================
# CLIENT COMMUNICATION
# ============================================================

@app.route(
    "/client/communication",
    methods=["GET", "POST"]
)
@app.route(
    "/client/messages",
    endpoint="client_messages",
    methods=["GET", "POST"]
)
def client_communication():

    if not client_required():

        return redirect(
            url_for("login")
        )


    client = get_logged_in_client()


    if client is None:

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        new_message = {

            "id":
                get_next_id(communications),

            "client_name":
                client.get("name", ""),

            "case_number":
                request.form.get("case_number", "").strip(),

            "subject":
                request.form.get("subject", "").strip(),

            "message":
                request.form.get("message", "").strip(),

            "date":
                date.today().isoformat(),

            "sender":
                "Client",

            "status":
                "Sent"
        }

        communications.append(new_message)
        db.save("communications", communications)

        return redirect(
            url_for("client_communication")
        )


    client_communications_list = (
        get_client_communications(
            client.get(
                "name",
                ""
            )
        )
    )


    return render_template(

        "client_messages.html",

        office_name=OFFICE_NAME,

        client=client,

        messages=
            client_communications_list,

        communications=
            client_communications_list

    )


@app.route(
    "/client/communications"
)
def client_communications():

    return redirect(
        url_for("client_communication")
    )


# ============================================================
# CLIENT PROFILE
# ============================================================

@app.route(
    "/client/profile",
    methods=["GET", "POST"]
)
def client_profile():

    if not client_required():

        return redirect(
            url_for("login")
        )


    client = get_logged_in_client()


    if client is None:

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        new_phone = request.form.get("phone", "").strip()
        new_address = request.form.get("address", "").strip()

        if new_phone:
            client["phone"] = new_phone

        client["address"] = new_address

        db.save("clients", clients)

        log_activity(
            actor=client.get("name", ""),
            action="Updated Profile",
            details="Updated phone/address"
        )

        return render_template(

            "client_profile.html",

            office_name=OFFICE_NAME,

            client=client,

            saved=True

        )


    return render_template(

        "client_profile.html",

        office_name=OFFICE_NAME,

        client=client

    )


# ============================================================
# CLIENT MANAGEMENT
# ============================================================

@app.route(
    "/clients"
)
def clients_page():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    search = request.args.get(
        "search",
        ""
    ).strip().lower()

    status_filter = request.args.get(
        "status",
        ""
    ).strip()


    if search:

        filtered_clients = [

            client

            for client in clients

            if (

                search in client.get(
                    "name",
                    ""
                ).lower()

                or

                search in client.get(
                    "phone",
                    ""
                ).lower()

                or

                search in client.get(
                    "email",
                    ""
                ).lower()

                or

                search in client.get(
                    "case_type",
                    ""
                ).lower()

            )

        ]

    else:

        filtered_clients = clients


    if status_filter:

        filtered_clients = [
            c for c in filtered_clients
            if c.get("status", "") == status_filter
        ]


    return render_template(

        "clients.html",

        clients=
            filtered_clients,

        search=
            search,

        status_filter=
            status_filter,

        office_name=
            OFFICE_NAME

    )


# ============================================================
# ADD CLIENT
# ============================================================

@app.route(
    "/clients/add",
    methods=["GET", "POST"]
)
def add_client():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        email = request.form.get(
            "email",
            ""
        ).strip().lower()


        for existing_client in clients:

            if existing_client.get(
                "email",
                ""
            ).strip().lower() == email:

                return render_template(

                    "add_client.html",

                    office_name=
                        OFFICE_NAME,

                    error=
                        "A client with this email already exists."

                )


        submitted_password = request.form.get("password", "").strip()
        generated_password = submitted_password or secrets.token_urlsafe(9)

        client = {

            "id":
                get_next_id(clients),

            "name":
                request.form.get(
                    "name",
                    ""
                ).strip(),

            "phone":
                request.form.get(
                    "phone",
                    ""
                ).strip(),

            "email":
                email,

            "password":
                generate_password_hash(generated_password),

            "address":
                request.form.get(
                    "address",
                    ""
                ).strip(),

            "case_type":
                request.form.get(
                    "case_type",
                    ""
                ).strip(),

            "status":
                "Active"
        }


        clients.append(
            client
        )
        db.save("clients", clients)

        log_activity(
            session.get("user_email", "Office"),
            "Added Client",
            client.get("name", "")
        )


        return render_template(

            "add_client.html",

            office_name=OFFICE_NAME,

            client_created=client,

            generated_password=(
                None if submitted_password else generated_password
            )

        )


    return render_template(

        "add_client.html",

        office_name=OFFICE_NAME

    )


# ============================================================
# CLIENT SEARCH
# ============================================================

@app.route(
    "/clients/search"
)
def search_clients():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    search = request.args.get(
        "search",
        ""
    ).strip().lower()


    results = [

        client

        for client in clients

        if (

            search in client.get(
                "name",
                ""
            ).lower()

            or

            search in client.get(
                "phone",
                ""
            ).lower()

            or

            search in client.get(
                "email",
                ""
            ).lower()

            or

            search in client.get(
                "case_type",
                ""
            ).lower()

        )

    ]


    return render_template(

        "clients.html",

        clients=
            results,

        search=
            search,

        office_name=
            OFFICE_NAME

    )


# ============================================================
# CASE MANAGEMENT
# ============================================================

@app.route(
    "/cases"
)
def cases_page():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    search = request.args.get(
        "search",
        ""
    ).strip().lower()

    status_filter = request.args.get(
        "status",
        ""
    ).strip()

    case_type_filter = request.args.get(
        "case_type",
        ""
    ).strip()


    if search:

        filtered_cases = [

            case

            for case in cases

            if (

                search in case.get(
                    "case_number",
                    ""
                ).lower()

                or

                search in case.get(
                    "client_name",
                    ""
                ).lower()

                or

                search in case.get(
                    "case_type",
                    ""
                ).lower()

                or

                search in case.get(
                    "court",
                    ""
                ).lower()

            )

        ]

    else:

        filtered_cases = cases


    if status_filter:

        filtered_cases = [
            c for c in filtered_cases
            if c.get("status", "") == status_filter
        ]


    if case_type_filter:

        filtered_cases = [
            c for c in filtered_cases
            if c.get("case_type", "") == case_type_filter
        ]


    case_types = sorted(set(
        c.get("case_type", "") for c in cases if c.get("case_type")
    ))


    return render_template(

        "cases.html",

        cases=
            filtered_cases,

        search=
            search,

        status_filter=
            status_filter,

        case_type_filter=
            case_type_filter,

        case_types=
            case_types,

        conflict_warning=
            request.args.get("conflict_warning"),

        conflict_score=
            request.args.get("conflict_score"),

        office_name=
            OFFICE_NAME

    )


# ============================================================
# ADD CASE
# ============================================================

@app.route(
    "/cases/add",
    methods=["GET", "POST"]
)
def add_case():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        case = {

            "id":
                get_next_id(cases),

            "case_number":
                request.form.get(
                    "case_number",
                    ""
                ).strip(),

            "client_name":
                request.form.get(
                    "client_name",
                    ""
                ).strip(),

            "case_type":
                request.form.get(
                    "case_type",
                    ""
                ).strip(),

            "court":
                request.form.get(
                    "court",
                    ""
                ).strip(),

            "filing_date":
                request.form.get(
                    "filing_date",
                    ""
                ),

            "status":
                request.form.get(
                    "status",
                    "Active"
                ),

            "description":
                request.form.get(
                    "description",
                    ""
                ).strip(),

            "fee_amount":
                float(
                    request.form.get("fee_amount", 0) or 0
                ),

            "opposing_party":
                request.form.get(
                    "opposing_party",
                    ""
                ).strip(),

            "stage":
                int(
                    request.form.get("stage", 1) or 1
                )
        }

        conflict_match = check_conflict_of_interest(
            case["opposing_party"]
        )

        if conflict_match:

            matched_name = conflict_match["client"].get("name", "")
            match_kind = (
                "exact match" if conflict_match["exact"]
                else f"{round(conflict_match['score'] * 100)}% similar"
            )

            log_activity(
                session.get("user_email", "Office"),
                "Conflict of Interest Flagged",
                f"New case names '{case['opposing_party']}' as opposing party "
                f"— {match_kind} to existing client {matched_name}"
            )


        cases.append(
            case
        )
        db.save("cases", cases)

        log_activity(
            session.get("user_email", "Office"),
            "Added Case",
            case.get("case_number", "")
        )


        return redirect(
            url_for(
                "cases_page",
                conflict_warning=(
                    conflict_match["client"].get("name") if conflict_match else None
                ),
                conflict_score=(
                    round(conflict_match["score"] * 100) if conflict_match else None
                )
            )
        )


    return render_template(

        "add_case.html",

        office_name=
            OFFICE_NAME,

        clients=
            clients

    )


# ============================================================
# CASE SEARCH
# ============================================================

@app.route(
    "/cases/search"
)
def search_cases():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    search = request.args.get(
        "search",
        ""
    ).strip().lower()


    results = [

        case

        for case in cases

        if (

            search in case.get(
                "case_number",
                ""
            ).lower()

            or

            search in case.get(
                "client_name",
                ""
            ).lower()

            or

            search in case.get(
                "case_type",
                ""
            ).lower()

            or

            search in case.get(
                "court",
                ""
            ).lower()

        )

    ]


    return render_template(

        "cases.html",

        cases=
            results,

        search=
            search,

        office_name=
            OFFICE_NAME

    )


# ============================================================
# CALENDAR VIEW (staff / advocate)
# ============================================================

@app.route(
    "/calendar"
)
def calendar_view():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    import calendar as cal_module

    year = int(request.args.get("year", date.today().year))
    month = int(request.args.get("month", date.today().month))

    cal = cal_module.Calendar(firstweekday=6)  # Sunday-first
    month_days = cal.monthdatescalendar(year, month)

    events_by_date = {}

    for hearing in hearings:
        d = hearing.get("date", "")
        events_by_date.setdefault(d, []).append({
            "type": "Hearing",
            "label": f"{hearing.get('client_name', '')} — {hearing.get('court', '')}",
            "time": hearing.get("time", ""),
        })

    for appt in appointments:
        d = appt.get("date", "")
        events_by_date.setdefault(d, []).append({
            "type": "Appointment",
            "label": appt.get("name", ""),
            "time": appt.get("time", ""),
        })

    # previous / next month for navigation
    if month == 1:
        prev_month, prev_year = 12, year - 1
    else:
        prev_month, prev_year = month - 1, year

    if month == 12:
        next_month, next_year = 1, year + 1
    else:
        next_month, next_year = month + 1, year

    return render_template(

        "calendar.html",

        office_name=OFFICE_NAME,

        month_days=month_days,

        events_by_date=events_by_date,

        current_month_name=cal_module.month_name[month],

        current_year=year,

        current_month=month,

        today=date.today().isoformat(),

        prev_month=prev_month,
        prev_year=prev_year,
        next_month=next_month,
        next_year=next_year

    )


# ============================================================
# HEARING MANAGEMENT
# ============================================================

@app.route(
    "/hearings"
)
def hearings_page():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    search = request.args.get(
        "search",
        ""
    ).strip().lower()

    status_filter = request.args.get(
        "status",
        ""
    ).strip()

    date_from = request.args.get(
        "date_from",
        ""
    ).strip()

    date_to = request.args.get(
        "date_to",
        ""
    ).strip()


    if search:

        filtered_hearings = [

            hearing

            for hearing in hearings

            if (

                search in hearing.get(
                    "case_number",
                    ""
                ).lower()

                or

                search in hearing.get(
                    "client_name",
                    ""
                ).lower()

                or

                search in hearing.get(
                    "court",
                    ""
                ).lower()

            )

        ]

    else:

        filtered_hearings = hearings


    if status_filter:

        filtered_hearings = [
            h for h in filtered_hearings
            if h.get("status", "") == status_filter
        ]


    if date_from:

        filtered_hearings = [
            h for h in filtered_hearings
            if h.get("date", "") >= date_from
        ]


    if date_to:

        filtered_hearings = [
            h for h in filtered_hearings
            if h.get("date", "") <= date_to
        ]


    return render_template(

        "hearings.html",

        hearings=
            filtered_hearings,

        search=
            search,

        status_filter=
            status_filter,

        date_from=
            date_from,

        date_to=
            date_to,

        office_name=
            OFFICE_NAME

    )


# ============================================================
# ADD HEARING
# ============================================================

@app.route(
    "/hearings/add",
    methods=["GET", "POST"]
)
def add_hearing():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        hearing = {

            "id":
                get_next_id(hearings),

            "case_number":
                request.form.get(
                    "case_number",
                    ""
                ).strip(),

            "client_name":
                request.form.get(
                    "client_name",
                    ""
                ).strip(),

            "court":
                request.form.get(
                    "court",
                    ""
                ).strip(),

            "date":
                request.form.get(
                    "date",
                    ""
                ),

            "time":
                request.form.get(
                    "time",
                    ""
                ),

            "purpose":
                request.form.get(
                    "purpose",
                    ""
                ).strip(),

            "status":
                "Scheduled"
        }


        hearings.append(
            hearing
        )
        db.save("hearings", hearings)


        return redirect(
            url_for("hearings_page")
        )


    return render_template(

        "add_hearing.html",

        office_name=
            OFFICE_NAME,

        cases=
            cases

    )


# ============================================================
# TODAY'S HEARINGS
# ============================================================

@app.route(
    "/hearings/today"
)
def today_hearings():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    today = date.today().isoformat()


    today_list = [

        hearing

        for hearing in hearings

        if hearing.get(
            "date"
        ) == today

    ]


    return render_template(

        "hearings.html",

        hearings=
            today_list,

        search=
            "",

        office_name=
            OFFICE_NAME,

        today=
            today

    )


# ============================================================
# APPOINTMENT MANAGEMENT
# ============================================================

@app.route(
    "/appointments"
)
def appointments_page():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    status = request.args.get(
        "status",
        ""
    ).strip()


    if status:

        filtered_appointments = [

            appointment

            for appointment in appointments

            if appointment.get(
                "status"
            ) == status

        ]

    else:

        filtered_appointments = appointments


    return render_template(

        "appointments.html",

        appointments=
            filtered_appointments,

        selected_status=
            status,

        office_name=
            OFFICE_NAME

    )


# ============================================================
# UPDATE APPOINTMENT STATUS
# ============================================================

@app.route(
    "/appointments/<int:appointment_id>/status",
    methods=["POST"]
)
def update_appointment_status(
    appointment_id
):

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    new_status = request.form.get(
        "status",
        "Pending"
    )


    allowed_statuses = [

        "Pending",

        "Approved",

        "Rejected",

        "Completed"

    ]


    if new_status not in allowed_statuses:

        new_status = "Pending"


    for appointment in appointments:

        if appointment.get(
            "id"
        ) == appointment_id:

            appointment["status"] = new_status

            break

    db.save("appointments", appointments)

    return redirect(
        url_for("appointments_page")
    )


# ============================================================
# TODAY'S APPOINTMENTS
# ============================================================

@app.route(
    "/appointments/today"
)
def today_appointments():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    today = date.today().isoformat()


    today_list = [

        appointment

        for appointment in appointments

        if appointment.get(
            "date"
        ) == today

    ]


    return render_template(

        "appointments.html",

        appointments=
            today_list,

        selected_status=
            "",

        office_name=
            OFFICE_NAME,

        today=
            today

    )


# ============================================================
# PAYMENT INVOICE (printable)
# ============================================================

@app.route(
    "/payments/<int:payment_id>/invoice"
)
def payment_invoice(payment_id):

    if session.get("user_role") not in ["advocate", "staff", "client"]:

        return redirect(
            url_for("login")
        )

    payment = None

    for p in payments:

        if p.get("id") == payment_id:
            payment = p
            break

    if payment is None:

        return redirect(
            url_for("login")
        )

    if session.get("user_role") == "client":

        client = get_logged_in_client()

        if (
            client is None
            or payment.get("client_name", "").strip().lower()
            != client.get("name", "").strip().lower()
        ):

            return redirect(
                url_for("client_payments")
            )

    log_activity(
        session.get("user_email", "Unknown"),
        "Viewed Invoice",
        f"Payment #{payment_id}"
    )

    return render_template(

        "payment_invoice.html",

        office_name=OFFICE_NAME,

        payment=payment

    )


# ============================================================
# PAYMENT MANAGEMENT
# ============================================================

@app.route(
    "/payments"
)
def payments_page():

    if not advocate_only_required():

        if session.get("user_role") == "staff":
            return redirect(
                url_for("staff_dashboard")
            )

        return redirect(
            url_for("login")
        )


    search = request.args.get(
        "search",
        ""
    ).strip().lower()


    if search:

        filtered_payments = [

            payment

            for payment in payments

            if (

                search in str(
                    payment.get(
                        "client_name",
                        ""
                    )
                ).lower()

                or

                search in str(
                    payment.get(
                        "case_number",
                        ""
                    )
                ).lower()

                or

                search in str(
                    payment.get(
                        "method",
                        ""
                    )
                ).lower()

                or

                search in str(
                    payment.get(
                        "status",
                        ""
                    )
                ).lower()

                or

                search in str(
                    payment.get(
                        "payer",
                        ""
                    )
                ).lower()

                or

                search in str(
                    payment.get(
                        "payment_reference",
                        ""
                    )
                ).lower()

                or

                search in str(
                    payment.get(
                        "description",
                        ""
                    )
                ).lower()

            )

        ]

    else:

        filtered_payments = payments


    total_amount = calculate_total_payments(
        filtered_payments
    )


    # ============================================================
    # CLIENT PAYMENT SUMMARY (per-client totals, for staff/advocate view)
    # ============================================================
    # "Billed" = sum of the fee_amount on each of the client's cases.
    # "Paid" = sum of their recorded payments with status "Paid".
    # "Due" = billed minus paid.

    client_payment_summary = []
    _seen_clients = set()

    _client_names_with_cases_or_payments = (
        [c.get("client_name", "").strip() for c in cases]
        + [p.get("client_name", "").strip() for p in filtered_payments]
    )

    for client_name in _client_names_with_cases_or_payments:

        if not client_name or client_name in _seen_clients:
            continue

        _seen_clients.add(client_name)

        client_cases_only = [
            c for c in cases
            if c.get("client_name", "").strip() == client_name
        ]

        client_payments_only = [
            p for p in filtered_payments
            if p.get("client_name", "").strip() == client_name
        ]

        total_fees = sum(
            float(c.get("fee_amount", 0) or 0) for c in client_cases_only
        )

        paid_amount = sum(
            float(p.get("amount", 0) or 0)
            for p in client_payments_only
            if p.get("status") == "Paid"
        )

        pending_amount = max(total_fees - paid_amount, 0)

        client_payment_summary.append({
            "client_name": client_name,
            "payment_count": len(client_payments_only),
            "total_fees": total_fees,
            "paid_amount": paid_amount,
            "pending_amount": pending_amount,
        })


    return render_template(

        "payments.html",

        payments=
            filtered_payments,

        search=
            search,

        total_amount=
            total_amount,

        client_payment_summary=
            client_payment_summary,

        is_client=
            False,

        office_name=
            OFFICE_NAME

    )


# ============================================================
# ADD PAYMENT
# ============================================================

@app.route(
    "/payments/add",
    methods=["GET", "POST"]
)
def add_payment():

    if not advocate_only_required():

        if session.get("user_role") == "staff":
            return redirect(
                url_for("staff_dashboard")
            )

        return redirect(
            url_for("login")
        )


    # ========================================================
    # DISPLAY FORM
    # ========================================================

    if request.method == "GET":

        return render_template(

            "add_payment.html",

            office_name=
                OFFICE_NAME,

            clients=
                clients,

            cases=
                cases,

            current_user=
                session.get(
                    "user_email",
                    ""
                ),

            current_role=
                session.get(
                    "user_role",
                    ""
                )

        )


    # ========================================================
    # FORM DATA
    # ========================================================

    client_name = request.form.get(
        "client_name",
        ""
    ).strip()


    case_number = request.form.get(
        "case_number",
        ""
    ).strip()


    amount_text = request.form.get(
        "amount",
        ""
    ).strip()


    payment_date = request.form.get(
        "date",
        ""
    ).strip()


    method = request.form.get(
        "method",
        ""
    ).strip()


    status = request.form.get(
        "status",
        "Paid"
    ).strip()


    payer = request.form.get(
        "payer",
        ""
    ).strip()


    payment_reference = request.form.get(
        "payment_reference",
        ""
    ).strip()


    description = request.form.get(
        "description",
        ""
    ).strip()


    # ========================================================
    # VALIDATE CLIENT
    # ========================================================

    selected_client = None


    for client in clients:

        if client.get(
            "name",
            ""
        ).strip().lower() == client_name.lower():

            selected_client = client

            break


    if selected_client is None:

        return render_template(

            "add_payment.html",

            office_name=
                OFFICE_NAME,

            clients=
                clients,

            cases=
                cases,

            current_user=
                session.get(
                    "user_email",
                    ""
                ),

            current_role=
                session.get(
                    "user_role",
                    ""
                ),

            error=
                "Please select a valid client."

        )


    # ========================================================
    # VALIDATE AMOUNT
    # ========================================================

    try:

        amount = float(
            amount_text
        )

    except (
        ValueError,
        TypeError
    ):

        return render_template(

            "add_payment.html",

            office_name=
                OFFICE_NAME,

            clients=
                clients,

            cases=
                cases,

            current_user=
                session.get(
                    "user_email",
                    ""
                ),

            current_role=
                session.get(
                    "user_role",
                    ""
                ),

            error=
                "Please enter a valid payment amount."

        )


    if amount <= 0:

        return render_template(

            "add_payment.html",

            office_name=
                OFFICE_NAME,

            clients=
                clients,

            cases=
                cases,

            current_user=
                session.get(
                    "user_email",
                    ""
                ),

            current_role=
                session.get(
                    "user_role",
                    ""
                ),

            error=
                "Payment amount must be greater than zero."

        )


    # ========================================================
    # PAYMENT DATE
    # ========================================================

    if not payment_date:

        payment_date = date.today().isoformat()


    # ========================================================
    # PAYER
    # ========================================================

    if not payer:

        payer = selected_client.get(
            "name",
            client_name
        )


    # ========================================================
    # PAYMENT METHODS
    # ========================================================

    allowed_methods = [

        "Cash",

        "UPI",

        "Bank Transfer",

        "Cheque",

        "Card"

    ]


    if method not in allowed_methods:

        method = "Cash"


    # ========================================================
    # PAYMENT STATUS
    # ========================================================

    allowed_statuses = [

        "Paid",

        "Pending",

        "Partial",

        "Cancelled"

    ]


    if status not in allowed_statuses:

        status = "Paid"


    # ========================================================
    # WHO RECEIVED THE PAYMENT
    # ========================================================

    current_role = session.get(
        "user_role",
        "staff"
    )


    if current_role == "advocate":

        received_by = "Advocate Office"

    else:

        received_by = "Staff"


    # ========================================================
    # CREATE PAYMENT RECORD
    # ========================================================

    payment = {

        "id":
            get_next_id(payments),

        "client_name":
            selected_client.get(
                "name",
                client_name
            ),

        "case_number":
            case_number,

        "amount":
            amount,

        "date":
            payment_date,

        "method":
            method,

        "status":
            status,

        "payer":
            payer,

        "received_by":
            received_by,

        "payment_reference":
            payment_reference,

        "description":
            description

    }


    # ========================================================
    # SAVE PAYMENT
    # ========================================================

    payments.append(
        payment
    )
    db.save("payments", payments)


    return redirect(
        url_for(
            "payments_page"
        )
    )


# ============================================================
# DOCUMENT MANAGEMENT
# ============================================================

@app.route(
    "/documents"
)
def documents_page():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    search = request.args.get(
        "search",
        ""
    ).strip().lower()


    direction = request.args.get(
        "direction",
        ""
    ).strip().lower()


    filtered_documents = documents


    # ========================================================
    # SEARCH
    # ========================================================

    if search:

        filtered_documents = [

            document

            for document in filtered_documents

            if (

                search in str(
                    document.get(
                        "document_name",
                        ""
                    )
                ).lower()

                or

                search in str(
                    document.get(
                        "client_name",
                        ""
                    )
                ).lower()

                or

                search in str(
                    document.get(
                        "case_number",
                        ""
                    )
                ).lower()

                or

                search in str(
                    document.get(
                        "document_type",
                        ""
                    )
                ).lower()

                or

                search in str(
                    document.get(
                        "status",
                        ""
                    )
                ).lower()

                or

                search in str(
                    document.get(
                        "direction",
                        ""
                    )
                ).lower()

                or

                search in str(
                    document.get(
                        "sender",
                        ""
                    )
                ).lower()

                or

                search in str(
                    document.get(
                        "receiver",
                        ""
                    )
                ).lower()

            )

        ]


    # ========================================================
    # DIRECTION FILTER
    # ========================================================

    if direction in [

        "received",

        "sent",

        "office"

    ]:

        filtered_documents = [

            document

            for document in filtered_documents

            if document.get(
                "direction",
                ""
            ).lower() == direction

        ]


    # ========================================================
    # SORT (making "Organized Records" a real feature)
    # ========================================================

    sort_by = request.args.get("sort", "").strip().lower()

    if sort_by == "client":
        filtered_documents = sorted(
            filtered_documents,
            key=lambda d: d.get("client_name", "").lower()
        )
    elif sort_by == "case":
        filtered_documents = sorted(
            filtered_documents,
            key=lambda d: d.get("case_number", "")
        )
    elif sort_by == "type":
        filtered_documents = sorted(
            filtered_documents,
            key=lambda d: d.get("document_type", "").lower()
        )
    elif sort_by == "date":
        filtered_documents = sorted(
            filtered_documents,
            key=lambda d: d.get("date", ""),
            reverse=True
        )


    return render_template(

        "documents.html",

        documents=
            filtered_documents,

        search=
            search,

        direction=
            direction,

        sort_by=
            sort_by,

        office_name=
            OFFICE_NAME

    )


# ============================================================
# ADD DOCUMENT
# ============================================================

@app.route(
    "/documents/add",
    methods=["GET", "POST"]
)
def add_document():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        document_name = request.form.get(
            "document_name",
            ""
        ).strip()

        client_name = request.form.get(
            "client_name",
            ""
        ).strip()

        case_number = request.form.get(
            "case_number",
            ""
        ).strip()

        document_type = request.form.get(
            "document_type",
            ""
        ).strip()

        document_date = request.form.get(
            "date",
            ""
        ).strip()

        description = request.form.get(
            "description",
            ""
        ).strip()

        uploaded_file = request.files.get(
            "document_file"
        )


        file_name = ""

        file_path = ""


        if (
            uploaded_file
            and uploaded_file.filename
        ):

            if not allowed_file(
                uploaded_file.filename
            ):

                return render_template(

                    "add_document.html",

                    office_name=
                        OFFICE_NAME,

                    clients=
                        clients,

                    cases=
                        cases,

                    error=
                        "File type is not allowed."

                )


            original_name = secure_filename(
                uploaded_file.filename
            )


            unique_name = (

                str(
                    get_next_id(documents)
                )

                + "_"

                + original_name

            )


            save_path = os.path.join(

                app.config[
                    "UPLOAD_FOLDER"
                ],

                unique_name

            )


            uploaded_file.save(
                save_path
            )


            file_name = original_name

            file_path = (
                "uploads/"
                + unique_name
            )


        document = {

            "id":
                get_next_id(documents),

            "document_name":
                document_name,

            "client_name":
                client_name,

            "case_number":
                case_number,

            "document_type":
                document_type,

            "date":
                document_date
                if document_date
                else date.today().isoformat(),

            "description":
                description,

            "status":
                "Available",

            "signature_status":
                request.form.get(
                    "signature_status",
                    "Not Required"
                ).strip() or "Not Required",

            "direction":
                "Office",

            "sender":
                "Advocate Office",

            "receiver":
                client_name,

            "file_name":
                file_name,

            "file_path":
                file_path

        }


        documents.append(
            document
        )
        db.save("documents", documents)


        return redirect(
            url_for("documents_page")
        )


    return render_template(

        "add_document.html",

        office_name=
            OFFICE_NAME,

        clients=
            clients,

        cases=
            cases

    )


# ============================================================
# RECEIVE DOCUMENT FROM CLIENT
# ============================================================

@app.route(
    "/documents/receive",
    methods=["GET", "POST"]
)
def receive_document():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        document_name = request.form.get(
            "document_name",
            ""
        ).strip()

        client_name = request.form.get(
            "client_name",
            ""
        ).strip()

        case_number = request.form.get(
            "case_number",
            ""
        ).strip()

        document_type = request.form.get(
            "document_type",
            ""
        ).strip()

        description = request.form.get(
            "description",
            ""
        ).strip()

        uploaded_file = request.files.get(
            "document_file"
        )


        if not document_name:

            return render_template(

                "receive_document.html",

                office_name=
                    OFFICE_NAME,

                clients=
                    clients,

                cases=
                    cases,

                error=
                    "Please enter the document name."

            )


        if not client_name:

            return render_template(

                "receive_document.html",

                office_name=
                    OFFICE_NAME,

                clients=
                    clients,

                cases=
                    cases,

                error=
                    "Please select a client."

            )


        file_name = ""

        file_path = ""


        if (
            uploaded_file
            and uploaded_file.filename
        ):

            if not allowed_file(
                uploaded_file.filename
            ):

                return render_template(

                    "receive_document.html",

                    office_name=
                        OFFICE_NAME,

                    clients=
                        clients,

                    cases=
                        cases,

                    error=
                        "File type is not allowed."

                )


            original_name = secure_filename(
                uploaded_file.filename
            )


            unique_name = (

                str(
                    get_next_id(documents)
                )

                + "_received_"

                + original_name

            )


            save_path = os.path.join(

                app.config[
                    "UPLOAD_FOLDER"
                ],

                unique_name

            )


            uploaded_file.save(
                save_path
            )


            file_name = original_name

            file_path = (
                "uploads/"
                + unique_name
            )


        document = {

            "id":
                get_next_id(documents),

            "document_name":
                document_name,

            "client_name":
                client_name,

            "case_number":
                case_number,

            "document_type":
                document_type,

            "date":
                date.today().isoformat(),

            "description":
                description,

            "status":
                "Received",

            "signature_status":
                "Not Required",

            "direction":
                "Received",

            "sender":
                client_name,

            "receiver":
                "Advocate Office",

            "file_name":
                file_name,

            "file_path":
                file_path

        }


        documents.append(
            document
        )
        db.save("documents", documents)


        return redirect(
            url_for(
                "documents_page"
            )
        )


    return render_template(

        "receive_document.html",

        office_name=
            OFFICE_NAME,

        clients=
            clients,

        cases=
            cases

    )


# ============================================================
# SEND DOCUMENT TO CLIENT
# ============================================================

@app.route(
    "/documents/send",
    methods=["GET", "POST"]
)
def send_document():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    if request.method == "POST":

        document_name = request.form.get(
            "document_name",
            ""
        ).strip()

        client_name = request.form.get(
            "client_name",
            ""
        ).strip()

        case_number = request.form.get(
            "case_number",
            ""
        ).strip()

        document_type = request.form.get(
            "document_type",
            ""
        ).strip()

        description = request.form.get(
            "description",
            ""
        ).strip()

        uploaded_file = request.files.get(
            "document_file"
        )


        if not document_name:

            return render_template(

                "send_document.html",

                office_name=
                    OFFICE_NAME,

                clients=
                    clients,

                cases=
                    cases,

                error=
                    "Please enter the document name."

            )


        if not client_name:

            return render_template(

                "send_document.html",

                office_name=
                    OFFICE_NAME,

                clients=
                    clients,

                cases=
                    cases,

                error=
                    "Please select a client."

            )


        file_name = ""

        file_path = ""


        if (
            uploaded_file
            and uploaded_file.filename
        ):

            if not allowed_file(
                uploaded_file.filename
            ):

                return render_template(

                    "send_document.html",

                    office_name=
                        OFFICE_NAME,

                    clients=
                        clients,

                    cases=
                        cases,

                    error=
                        "File type is not allowed."

                )


            original_name = secure_filename(
                uploaded_file.filename
            )


            unique_name = (

                str(
                    get_next_id(documents)
                )

                + "_sent_"

                + original_name

            )


            save_path = os.path.join(

                app.config[
                    "UPLOAD_FOLDER"
                ],

                unique_name

            )


            uploaded_file.save(
                save_path
            )


            file_name = original_name

            file_path = (
                "uploads/"
                + unique_name
            )


        document = {

            "id":
                get_next_id(documents),

            "document_name":
                document_name,

            "client_name":
                client_name,

            "case_number":
                case_number,

            "document_type":
                document_type,

            "date":
                date.today().isoformat(),

            "description":
                description,

            "status":
                "Sent",

            "signature_status":
                request.form.get(
                    "signature_status",
                    "Not Required"
                ).strip() or "Not Required",

            "direction":
                "Sent",

            "sender":
                "Advocate Office",

            "receiver":
                client_name,

            "file_name":
                file_name,

            "file_path":
                file_path

        }


        documents.append(
            document
        )
        db.save("documents", documents)


        return redirect(
            url_for(
                "documents_page"
            )
        )


    return render_template(

        "send_document.html",

        office_name=
            OFFICE_NAME,

        clients=
            clients,

        cases=
            cases

    )


# ============================================================
# DOCUMENT SEARCH
# ============================================================

@app.route(
    "/documents/search"
)
def search_documents():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )


    search = request.args.get(
        "search",
        ""
    ).strip().lower()


    results = [

        document

        for document in documents

        if (

            search in str(
                document.get(
                    "document_name",
                    ""
                )
            ).lower()

            or

            search in str(
                document.get(
                    "client_name",
                    ""
                )
            ).lower()

            or

            search in str(
                document.get(
                    "case_number",
                    ""
                )
            ).lower()

            or

            search in str(
                document.get(
                    "document_type",
                    ""
                )
            ).lower()

            or

            search in str(
                document.get(
                    "direction",
                    ""
                )
            ).lower()

            or

            search in str(
                document.get(
                    "sender",
                    ""
                )
            ).lower()

            or

            search in str(
                document.get(
                    "receiver",
                    ""
                )
            ).lower()

            or

            search in str(
                document.get(
                    "status",
                    ""
                )
            ).lower()

        )

    ]


    return render_template(

        "documents.html",

        documents=
            results,

        search=
            search,

        direction=
            "",

        office_name=
            OFFICE_NAME

    )


# ============================================================
# VIEW / DOWNLOAD DOCUMENT
# ============================================================

@app.route(
    "/documents/view/<int:document_id>"
)
def view_document(document_id):

    document = None


    for item in documents:

        if item.get(
            "id"
        ) == document_id:

            document = item

            break


    if document is None:

        return redirect(
            url_for("documents_page")
        )


    # ========================================================
    # USER MUST BE LOGGED IN
    # ========================================================

    if session.get(
        "user_role"
    ) not in [

        "advocate",

        "staff",

        "client"

    ]:

        return redirect(
            url_for("login")
        )


    log_activity(
        session.get("user_email", "Unknown"),
        "Viewed Document",
        document.get("document_name", "")
    )


    # ========================================================
    # CLIENT CAN ONLY VIEW OWN DOCUMENTS
    # ========================================================

    if session.get(
        "user_role"
    ) == "client":

        client = get_logged_in_client()


        if client is None:

            return redirect(
                url_for("login")
            )


        if document.get(
            "client_name",
            ""
        ).strip().lower() != client.get(
            "name",
            ""
        ).strip().lower():

            return redirect(
                url_for("client_documents")
            )


    # ========================================================
    # FILE PATH
    # ========================================================

    file_path = document.get(
        "file_path",
        ""
    )


    if not file_path:

        return render_template_string(

            """
            <!DOCTYPE html>

            <html>

            <head>

                <title>
                    Document
                </title>

                <style>

                    body {
                        font-family: Arial;
                        background: #f5f7fb;
                        padding: 40px;
                    }

                    .card {
                        max-width: 600px;
                        margin: auto;
                        background: white;
                        padding: 30px;
                        border-radius: 15px;
                        box-shadow: 0 5px 20px rgba(0,0,0,.08);
                    }

                    a {
                        display: inline-block;
                        margin-top: 20px;
                        padding: 10px 18px;
                        background: #17324d;
                        color: white;
                        text-decoration: none;
                        border-radius: 7px;
                    }

                </style>

            </head>

            <body>

                <div class="card">

                    <h2>
                        {{ document.document_name }}
                    </h2>

                    <p>
                        No physical file has been uploaded
                        for this document record.
                    </p>

                    <a href="{{ url_for('documents_page') }}">
                        Back
                    </a>

                </div>

            </body>

            </html>
            """,

            document=
                document

        )


    return redirect(

        url_for(

            "static",

            filename=
                file_path

        )

    )


# ============================================================
# CLIENT: SIGN A DOCUMENT
# ============================================================

@app.route(
    "/client/documents/<int:document_id>/sign",
    methods=["POST"]
)
def sign_document(document_id):

    if not client_required():

        return redirect(
            url_for("login")
        )

    client = get_logged_in_client()

    if client is None:

        return redirect(
            url_for("login")
        )

    for document in documents:

        if document.get("id") == document_id:

            if document.get(
                "client_name", ""
            ).strip().lower() == client.get(
                "name", ""
            ).strip().lower():

                document["signature_status"] = "Signed"
                db.save("documents", documents)

                log_activity(
                    client.get("name", ""),
                    "Signed Document",
                    document.get("document_name", "")
                )

            break

    return redirect(
        url_for("client_documents")
    )


# ============================================================
# LOGOUT
# ============================================================

@app.route(
    "/logout"
)
def logout():

    session.clear()

    return redirect(
        url_for("login")
    )


# ============================================================
# ERROR 404
# ============================================================

@app.errorhandler(404)
def page_not_found(error):

    return render_template(

        "404.html",

        office_name=
            OFFICE_NAME

    ), 404


# ============================================================
# AUDIT LOG (advocate only)
# ============================================================

@app.route(
    "/cases/<case_number>/notes",
    methods=["GET", "POST"]
)
def case_notes_page(case_number):

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    case = None

    for c in cases:

        if c.get("case_number") == case_number:
            case = c
            break

    if case is None:

        return redirect(
            url_for("cases_page")
        )

    if request.method == "POST":

        note_text = request.form.get("note", "").strip()

        if note_text:

            note = {
                "id": get_next_id(case_notes),
                "case_number": case_number,
                "author": session.get("user_email", "Office"),
                "note": note_text,
                "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
            }

            case_notes.append(note)
            db.save("case_notes", case_notes)

            log_activity(
                session.get("user_email", "Office"),
                "Added Case Note",
                case_number
            )

        return redirect(
            url_for("case_notes_page", case_number=case_number)
        )

    notes_for_case = [
        n for n in case_notes
        if n.get("case_number") == case_number
    ]

    return render_template(

        "case_notes.html",

        office_name=OFFICE_NAME,

        case=case,

        notes=list(reversed(notes_for_case))

    )


@app.route(
    "/audit-log"
)
def audit_log_page():

    if session.get("user_role") != "advocate":

        return redirect(
            url_for("login")
        )

    return render_template(

        "audit_log.html",

        office_name=OFFICE_NAME,

        entries=list(reversed(audit_log))

    )


# ============================================================
# REPORTS (staff / advocate)
# ============================================================

@app.route(
    "/reports"
)
def reports():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    active_case_count = len([
        case
        for case in cases
        if case.get("status") == "Active"
    ])

    return render_template(

        "reports.html",

        office_name=OFFICE_NAME,

        total_clients=len(clients),
        total_cases=len(cases),
        active_cases=active_case_count,
        total_hearings=len(hearings),
        total_appointments=len(appointments),
        total_payment=
            f"{calculate_total_payments(payments):,.2f}",
        total_staff=5

    )


# ============================================================
# SETTINGS (staff / advocate)
# ============================================================

@app.route(
    "/settings",
    methods=["GET", "POST"]
)
def settings():

    global ADVOCATE_PASSWORD_HASH
    global STAFF_PASSWORD_HASH
    global office_hours_text

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    password_message = None
    password_error = None
    hours_message = None

    if request.method == "POST":

        if "hours_text" in request.form:

            new_hours = request.form.get("hours_text", "").strip()

            if new_hours:
                office_hours_text = new_hours

                log_activity(
                    session.get("user_email", session.get("user_role")),
                    "Updated Working Hours",
                    new_hours
                )

                hours_message = "Working hours updated."

        else:

            current_password = request.form.get("current_password", "")
            new_password = request.form.get("new_password", "")
            confirm_password = request.form.get("confirm_password", "")

            role = session.get("user_role")

            if role == "advocate":
                current_hash = ADVOCATE_PASSWORD_HASH
            else:
                current_hash = STAFF_PASSWORD_HASH

            if not _safe_check_password(current_hash, current_password):
                password_error = "Current password is incorrect."

            elif len(new_password) < 6:
                password_error = "New password must be at least 6 characters."

            elif new_password != confirm_password:
                password_error = "New password and confirmation do not match."

            else:

                if role == "advocate":
                    ADVOCATE_PASSWORD_HASH = generate_password_hash(new_password)
                else:
                    STAFF_PASSWORD_HASH = generate_password_hash(new_password)

                log_activity(
                    session.get("user_email", role),
                    "Changed Password",
                    f"{role} changed their own password"
                )

                password_message = "Your password has been updated."

    return render_template(
        "settings.html",
        office_name=OFFICE_NAME,
        password_message=password_message,
        password_error=password_error,
        hours_message=hours_message,
        office_hours_text=office_hours_text
    )


# ============================================================
# INTERNSHIP
# ============================================================

internship_applications = []
db.seed_if_empty("internship_applications", [])
internship_applications.extend(db.load("internship_applications"))

# ------------------------------------------------------------
# INTERNS
# ------------------------------------------------------------
interns = []
intern_tasks = []

db.seed_if_empty("interns", [])
db.seed_if_empty("intern_tasks", [])
interns.extend(db.load("interns"))
intern_tasks.extend(db.load("intern_tasks"))

# ------------------------------------------------------------
# AUDIT LOG (loaded from DB, replacing the empty list created earlier)
# ------------------------------------------------------------
db.seed_if_empty("audit_log", [])
audit_log.extend(db.load("audit_log"))

# ------------------------------------------------------------
# CASE NOTES
# ------------------------------------------------------------
case_notes = []
db.seed_if_empty("case_notes", [])
case_notes.extend(db.load("case_notes"))

# ------------------------------------------------------------
# PASSWORD RESET TOKENS
# ------------------------------------------------------------
password_reset_tokens = {}


def intern_required():
    return session.get("user_role") == "intern"


def get_logged_in_intern():

    email = session.get(
        "user_email", ""
    ).strip().lower()

    if not email:
        return None

    for intern in interns:

        if intern.get(
            "email", ""
        ).strip().lower() == email:

            return intern

    return None


@app.route("/fee-estimator")
def fee_estimator():

    return render_template(
        "fee_estimator.html",
        office_name=OFFICE_NAME
    )


@app.route("/faq")
def faq():

    return render_template(
        "faq.html",
        office_name=OFFICE_NAME
    )


@app.route("/terms")
def terms():

    return render_template(
        "terms.html",
        office_name=OFFICE_NAME
    )


@app.route("/privacy")
def privacy():

    return render_template(
        "privacy.html",
        office_name=OFFICE_NAME
    )


@app.route(
    "/internship"
)
def internship():

    return render_template(
        "internship.html",
        office_name=OFFICE_NAME
    )


@app.route(
    "/internship/status",
    methods=["GET", "POST"]
)
def internship_application_status():

    application = None
    searched = False

    if request.method == "POST":

        email = request.form.get("email", "").strip().lower()
        searched = True

        for item in internship_applications:

            if item.get("email", "").strip().lower() == email:
                application = item
                break

    return render_template(

        "internship_status.html",

        office_name=OFFICE_NAME,

        application=application,

        searched=searched

    )


@app.route(
    "/internship/apply",
    methods=["POST"]
)
def internship_apply():

    resume_file = request.files.get("resume")
    resume_filename = ""

    if resume_file and resume_file.filename and allowed_file(
        resume_file.filename
    ):
        resume_filename = secure_filename(resume_file.filename)
        resume_file.save(
            os.path.join(UPLOAD_FOLDER, resume_filename)
        )

    application = {
        "id": get_next_id(internship_applications),
        "full_name": request.form.get("full_name", "").strip(),
        "email": request.form.get("email", "").strip(),
        "phone": request.form.get("phone", "").strip(),
        "college": request.form.get("college", "").strip(),
        "course": request.form.get("course", "").strip(),
        "year": request.form.get("year", "").strip(),
        "area": request.form.get("area", "").strip(),
        "duration": request.form.get("duration", "").strip(),
        "message": request.form.get("message", "").strip(),
        "resume_filename": resume_filename,
        "date": date.today().isoformat(),
        "status": "Pending",
    }

    internship_applications.append(application)
    db.save("internship_applications", internship_applications)

    return redirect(
        url_for("internship", submitted=1)
    )


# ============================================================
# INTERNSHIP APPLICATIONS (staff / advocate review)
# ============================================================

@app.route(
    "/internship/applications"
)
def internship_applications_page():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    return render_template(

        "internship_applications.html",

        office_name=OFFICE_NAME,

        applications=internship_applications,

        interns=interns,

        intern_tasks=intern_tasks

    )


@app.route(
    "/internship/applications/<int:application_id>/approve",
    methods=["POST"]
)
def approve_internship_application(application_id):

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    application = None

    for item in internship_applications:

        if item.get("id") == application_id:
            application = item
            break

    generated_password = ""

    if application:

        already_intern = any(
            i.get("email", "").strip().lower()
            == application.get("email", "").strip().lower()
            for i in interns
        )

        if not already_intern:

            generated_password = "intern" + str(
                get_next_id(interns)
            ) + "23"

            new_intern = {
                "id": get_next_id(interns),
                "full_name": application.get("full_name", ""),
                "email": application.get("email", ""),
                "password": generate_password_hash(generated_password),
                "area": application.get("area", ""),
                "status": "Active",
                "date_joined": date.today().isoformat(),
            }

            interns.append(new_intern)
            db.save("interns", interns)

        application["status"] = "Approved"
        db.save("internship_applications", internship_applications)

        log_activity(
            session.get("user_email", "Office"),
            "Approved Internship Application",
            application.get("full_name", "")
        )

    return render_template(

        "internship_applications.html",

        office_name=OFFICE_NAME,

        applications=internship_applications,

        interns=interns,

        just_approved_email=
            application.get("email") if application else None,

        generated_password=
            generated_password

    )


@app.route(
    "/internship/applications/<int:application_id>/reject",
    methods=["POST"]
)
def reject_internship_application(application_id):

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    for item in internship_applications:

        if item.get("id") == application_id:

            item["status"] = "Rejected"

            log_activity(
                session.get("user_email", "Office"),
                "Rejected Internship Application",
                item.get("full_name", "")
            )

            break

    db.save("internship_applications", internship_applications)

    return redirect(
        url_for("internship_applications_page")
    )


# ============================================================
# INTERN TASKS (staff / advocate assign work)
# ============================================================

@app.route(
    "/intern/tasks/add",
    methods=["GET", "POST"]
)
def add_intern_task():

    if not staff_or_advocate_required():

        return redirect(
            url_for("login")
        )

    if request.method == "POST":

        task = {
            "id": get_next_id(intern_tasks),
            "intern_email": request.form.get(
                "intern_email", ""
            ).strip(),
            "title": request.form.get(
                "title", ""
            ).strip(),
            "description": request.form.get(
                "description", ""
            ).strip(),
            "status": "Pending",
            "assigned_date": date.today().isoformat(),
            "due_date": request.form.get(
                "due_date", ""
            ).strip(),
        }

        intern_tasks.append(task)
        db.save("intern_tasks", intern_tasks)

        return redirect(
            url_for("internship_applications_page")
        )

    return render_template(

        "add_intern_task.html",

        office_name=OFFICE_NAME,

        interns=interns

    )


# ============================================================
# INTERN DASHBOARD
# ============================================================

@app.route(
    "/intern/dashboard"
)
def intern_dashboard():

    if not intern_required():

        return redirect(
            url_for("login")
        )

    intern = get_logged_in_intern()

    if intern is None:

        session.clear()

        return redirect(
            url_for("login")
        )

    my_tasks = [
        t for t in intern_tasks
        if t.get("intern_email", "").strip().lower()
        == intern.get("email", "").strip().lower()
    ]

    pending_count = len([
        t for t in my_tasks if t.get("status") == "Pending"
    ])

    in_progress_count = len([
        t for t in my_tasks if t.get("status") == "In Progress"
    ])

    completed_count = len([
        t for t in my_tasks if t.get("status") == "Completed"
    ])

    return render_template(

        "intern_dashboard.html",

        office_name=OFFICE_NAME,

        intern=intern,

        tasks=my_tasks,

        pending_count=pending_count,

        in_progress_count=in_progress_count,

        completed_count=completed_count

    )


@app.route(
    "/intern/tasks/<int:task_id>/update",
    methods=["POST"]
)
def update_intern_task_status(task_id):

    if not intern_required():

        return redirect(
            url_for("login")
        )

    intern = get_logged_in_intern()

    if intern is None:

        return redirect(
            url_for("login")
        )

    new_status = request.form.get("status", "Pending").strip()

    if new_status not in ["Pending", "In Progress", "Completed"]:
        new_status = "Pending"

    for task in intern_tasks:

        if (
            task.get("id") == task_id
            and task.get("intern_email", "").strip().lower()
            == intern.get("email", "").strip().lower()
        ):

            task["status"] = new_status
            break

    db.save("intern_tasks", intern_tasks)

    return redirect(
        url_for("intern_dashboard")
    )


# ============================================================
# ERROR 500
# ============================================================

@app.errorhandler(500)
def internal_server_error(error):

    return render_template(

        "500.html",

        office_name=
            OFFICE_NAME

    ), 500


# ============================================================
# RUN APPLICATION
# ============================================================

if __name__ == "__main__":

    debug_mode = os.environ.get(
        "FLASK_DEBUG", "true"
    ).lower() == "true"

    app.run(

        debug=debug_mode,

        host="127.0.0.1",

        port=5000

    )
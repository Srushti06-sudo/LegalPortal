"""
============================================================
LEGALDESK DATABASE LAYER (MySQL)
============================================================

Real persistence for the app's data collections (clients,
cases, hearings, appointments, payments, documents,
communications) backed by MySQL.

Setup (command prompt):

    mysql -u root -p < schema.sql

Connection settings are read from environment variables so you
never have to hardcode credentials in source. Defaults assume a
local MySQL server with a root user and no password:

    LEGALDESK_DB_HOST      (default: localhost)
    LEGALDESK_DB_USER      (default: root)
    LEGALDESK_DB_PASSWORD  (default: "")
    LEGALDESK_DB_NAME      (default: legaldesk)

Usage from app.py:

    import database as db

    db.init_db()
    clients = db.load("clients")
    ...
    clients.append(new_client)
    db.save("clients", clients)
"""

import os
import mysql.connector
from mysql.connector import Error as MySQLError

DB_CONFIG = {
    "host": os.environ.get("LEGALDESK_DB_HOST", "localhost"),
    "user": os.environ.get("LEGALDESK_DB_USER", "root"),
    "password": os.environ.get("LEGALDESK_DB_PASSWORD", ""),
    "database": os.environ.get("LEGALDESK_DB_NAME", "legaldesk"),
}

# Column list per table, in the exact order they're stored.
# This must match schema.sql.
TABLE_COLUMNS = {
    "clients": [
        "id", "name", "phone", "email", "password",
        "address", "case_type", "status",
    ],
    "cases": [
        "id", "case_number", "client_name", "case_type",
        "court", "filing_date", "status", "description",
        "fee_amount", "opposing_party", "stage",
    ],
    "hearings": [
        "id", "case_number", "client_name", "court",
        "date", "time", "purpose", "status",
    ],
    "appointments": [
        "id", "name", "phone", "email", "date",
        "time", "service", "message", "status",
        "opposing_party", "conflict_flag", "conflict_score",
    ],
    "payments": [
        "id", "client_name", "case_number", "amount", "date",
        "method", "status", "payer", "received_by",
        "payment_reference", "description", "advocate",
    ],
    "documents": [
        "id", "document_name", "client_name", "case_number",
        "document_type", "date", "description", "status",
        "signature_status", "direction", "sender", "receiver",
        "file_name", "file_path",
    ],
    "communications": [
        "id", "subject", "message", "sender", "client_name",
        "case_number", "date", "status",
    ],
    "interns": [
        "id", "full_name", "email", "password",
        "area", "status", "date_joined",
    ],
    "intern_tasks": [
        "id", "intern_email", "title", "description",
        "status", "assigned_date", "due_date",
    ],
    "audit_log": [
        "id", "actor", "action", "details", "timestamp",
    ],
    "case_notes": [
        "id", "case_number", "author", "note", "date",
    ],
    "internship_applications": [
        "id", "full_name", "email", "phone", "college", "course",
        "year", "area", "duration", "message", "resume_filename",
        "date", "status",
    ],
}


def get_connection():
    return mysql.connector.connect(**DB_CONFIG)


def init_db():
    """
    Verify the database is reachable and the tables exist.
    Call once at app startup. Raises a clear error if MySQL
    isn't running or the schema hasn't been created yet.
    """

    try:
        conn = get_connection()
        conn.close()
    except MySQLError as exc:
        raise RuntimeError(
            "Could not connect to MySQL using the settings in "
            "database.py / your LEGALDESK_DB_* environment "
            "variables. Make sure MySQL is running and you have "
            "run: mysql -u root -p < schema.sql\n"
            f"Original error: {exc}"
        )


def is_empty(table):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM {table}")
    (count,) = cursor.fetchone()
    cursor.close()
    conn.close()
    return count == 0


def load(table):
    """
    Load every row of a table back into a list of dicts,
    in the same shape the rest of app.py already expects.
    """

    columns = TABLE_COLUMNS[table]
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(f"SELECT {', '.join(columns)} FROM {table} ORDER BY id ASC")
    rows = cursor.fetchall()
    cursor.close()
    conn.close()

    records = []
    for row in rows:
        record = dict(zip(columns, row))
        for key, value in record.items():
            # MySQL returns DATE columns as datetime.date objects;
            # the app works with plain ISO date strings.
            if hasattr(value, "isoformat"):
                record[key] = value.isoformat()
            elif value is None:
                record[key] = ""
        records.append(record)

    return records


def save(table, records):
    """
    Fully replace the contents of a table with the given list
    of dicts. Called after every add/update/delete so MySQL
    always reflects the current in-memory state.
    """

    columns = TABLE_COLUMNS[table]
    placeholders = ", ".join(["%s"] * len(columns))
    column_list = ", ".join(columns)

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(f"DELETE FROM {table}")

    for record in records:
        values = [record.get(col) for col in columns]
        cursor.execute(
            f"INSERT INTO {table} ({column_list}) VALUES ({placeholders})",
            values
        )

    conn.commit()
    cursor.close()
    conn.close()


def seed_if_empty(table, demo_records):
    """
    Populate a table with demo data only the first time the
    app is ever run against this database. Real changes made
    afterwards are never overwritten by a restart.
    """

    if is_empty(table):
        save(table, demo_records)

-- ============================================================
-- LEGALDESK MYSQL SCHEMA
-- ============================================================
-- Run this once from the command prompt to create the database
-- and all tables:
--
--     mysql -u root -p < schema.sql
--
-- (See README.md for full setup instructions.)
-- ============================================================

CREATE DATABASE IF NOT EXISTS legaldesk
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE legaldesk;

-- ------------------------------------------------------------
-- CLIENTS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clients (
    id          INT PRIMARY KEY,
    name        VARCHAR(150) NOT NULL,
    phone       VARCHAR(30),
    email       VARCHAR(150),
    password    VARCHAR(255),
    address     VARCHAR(255),
    case_type   VARCHAR(100),
    status      VARCHAR(30) DEFAULT 'Active'
);

-- ------------------------------------------------------------
-- CASES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cases (
    id           INT PRIMARY KEY,
    case_number  VARCHAR(50) NOT NULL,
    client_name  VARCHAR(150),
    case_type    VARCHAR(100),
    court        VARCHAR(150),
    filing_date  DATE NULL,
    status       VARCHAR(30) DEFAULT 'Active',
    description  TEXT,
    fee_amount   DECIMAL(12, 2) DEFAULT 0.00,
    opposing_party VARCHAR(150),
    stage        INT DEFAULT 1
);

-- ------------------------------------------------------------
-- HEARINGS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hearings (
    id           INT PRIMARY KEY,
    case_number  VARCHAR(50),
    client_name  VARCHAR(150),
    court        VARCHAR(150),
    date         DATE NULL,
    time         VARCHAR(20),
    purpose      VARCHAR(255),
    status       VARCHAR(30) DEFAULT 'Scheduled'
);

-- ------------------------------------------------------------
-- APPOINTMENTS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS appointments (
    id       INT PRIMARY KEY,
    name     VARCHAR(150),
    phone    VARCHAR(30),
    email    VARCHAR(150),
    date     DATE NULL,
    time     VARCHAR(20),
    service  VARCHAR(150),
    message  TEXT,
    status   VARCHAR(30) DEFAULT 'Pending',
    opposing_party VARCHAR(150),
    conflict_flag  TINYINT(1) DEFAULT 0,
    conflict_score INT DEFAULT 0
);

-- ------------------------------------------------------------
-- PAYMENTS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
    id                 INT PRIMARY KEY,
    client_name        VARCHAR(150),
    case_number        VARCHAR(50),
    amount             DECIMAL(12, 2) DEFAULT 0.00,
    date               DATE NULL,
    method             VARCHAR(50),
    status             VARCHAR(30) DEFAULT 'Paid',
    payer              VARCHAR(150),
    received_by        VARCHAR(150),
    payment_reference  VARCHAR(100),
    description        TEXT,
    advocate           VARCHAR(150)
);

-- ------------------------------------------------------------
-- DOCUMENTS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS documents (
    id             INT PRIMARY KEY,
    document_name  VARCHAR(200),
    client_name    VARCHAR(150),
    case_number    VARCHAR(50),
    document_type  VARCHAR(100),
    date           DATE NULL,
    description    TEXT,
    status         VARCHAR(30) DEFAULT 'Available',
    signature_status VARCHAR(30) DEFAULT 'Not Required',
    direction      VARCHAR(20),
    sender         VARCHAR(150),
    receiver       VARCHAR(150),
    file_name      VARCHAR(255),
    file_path      VARCHAR(500)
);

-- ------------------------------------------------------------
-- COMMUNICATIONS (internal office messaging)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS communications (
    id           INT PRIMARY KEY,
    subject      VARCHAR(200),
    message      TEXT,
    sender       VARCHAR(150),
    client_name  VARCHAR(150),
    case_number  VARCHAR(50),
    date         DATE NULL,
    status       VARCHAR(30) DEFAULT 'Unread'
);

-- ------------------------------------------------------------
-- INTERNS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS interns (
    id           INT PRIMARY KEY,
    full_name    VARCHAR(150) NOT NULL,
    email        VARCHAR(150) NOT NULL,
    password     VARCHAR(255),
    area         VARCHAR(100),
    status       VARCHAR(30) DEFAULT 'Active',
    date_joined  DATE NULL
);

-- ------------------------------------------------------------
-- INTERN TASKS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS intern_tasks (
    id             INT PRIMARY KEY,
    intern_email   VARCHAR(150),
    title          VARCHAR(200),
    description    TEXT,
    status         VARCHAR(30) DEFAULT 'Pending',
    assigned_date  DATE NULL,
    due_date       DATE NULL
);

-- ------------------------------------------------------------
-- AUDIT / ACTIVITY LOG
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    id         INT PRIMARY KEY,
    actor      VARCHAR(150),
    action     VARCHAR(150),
    details    TEXT,
    timestamp  VARCHAR(30)
);

-- ------------------------------------------------------------
-- CASE NOTES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS case_notes (
    id           INT PRIMARY KEY,
    case_number  VARCHAR(50),
    author       VARCHAR(150),
    note         TEXT,
    date         VARCHAR(30)
);

-- ------------------------------------------------------------
-- INTERNSHIP APPLICATIONS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS internship_applications (
    id               INT PRIMARY KEY,
    full_name        VARCHAR(150),
    email            VARCHAR(150),
    phone            VARCHAR(30),
    college          VARCHAR(200),
    course           VARCHAR(100),
    year             VARCHAR(30),
    area             VARCHAR(100),
    duration         VARCHAR(50),
    message          TEXT,
    resume_filename  VARCHAR(255),
    date             VARCHAR(30),
    status           VARCHAR(30) DEFAULT 'Pending'
);

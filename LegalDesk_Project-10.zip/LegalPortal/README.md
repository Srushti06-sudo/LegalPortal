# LegalDesk — Legal Assistance & Client Communication Portal

A Flask web application for a small advocate's office: public site,
client portal, and staff/advocate management dashboards for clients,
cases, hearings, appointments, payments, and documents.

Data is now stored in a real **MySQL** database instead of resetting
every time the server restarts.

```
LegalPortal/
├── backend/            <- the actual running application
│   ├── app.py          <- Flask app (routes, logic)
│   ├── database.py     <- MySQL persistence layer
│   ├── schema.sql       <- run this once to create the database
│   ├── requirements.txt
│   ├── templates/       <- all HTML pages (Jinja2)
│   └── static/          <- CSS, uploaded files
└── frontend/            <- an early static mockup, not used by the
                            running app; the real frontend is the
                            templates/ folder above, served by Flask
```

---

## 1. Install MySQL

If you don't already have MySQL installed:

- **Windows:** download and run the MySQL Installer from
  https://dev.mysql.com/downloads/installer/ and install
  "MySQL Server". During setup you'll set a root password —
  remember it for step 3.
- **macOS:** `brew install mysql && brew services start mysql`
- **Linux (Debian/Ubuntu):** `sudo apt install mysql-server`

Confirm it's running by opening a command prompt / terminal and
typing:

```
mysql -u root -p
```

Enter your root password. If you see a `mysql>` prompt, it's
working — type `exit` to leave it.

---

## 2. Create the database and tables

From the `backend/` folder, run:

```
mysql -u root -p < schema.sql
```

Enter your root password when prompted. This creates a `legaldesk`
database with all the tables the app needs. You can double-check it
worked:

```
mysql -u root -p -e "USE legaldesk; SHOW TABLES;"
```

You should see: `appointments`, `cases`, `clients`, `communications`,
`documents`, `hearings`, `payments`.

---

## 3. Configure your database credentials

The app reads its MySQL connection settings from environment
variables (so you never have to hardcode a password in source):

| Variable                 | Default     |
|---------------------------|-------------|
| `LEGALDESK_DB_HOST`       | `localhost` |
| `LEGALDESK_DB_USER`       | `root`      |
| `LEGALDESK_DB_PASSWORD`   | *(empty)*   |
| `LEGALDESK_DB_NAME`       | `legaldesk` |

If your MySQL root user has a password, set it before running the
app.

**Windows (Command Prompt):**
```
set LEGALDESK_DB_PASSWORD=your_password_here
```

**macOS / Linux:**
```
export LEGALDESK_DB_PASSWORD=your_password_here
```

If you use a different MySQL username or host, set
`LEGALDESK_DB_USER` / `LEGALDESK_DB_HOST` the same way.

---

## 4. Install Python dependencies

From the `backend/` folder:

```
pip install -r requirements.txt
```

---

## 5. Run the app

Still from `backend/`:

```
python app.py
```

You should see:

```
* Running on http://127.0.0.1:5000
```

Open that address in your browser.

**First run:** the app automatically seeds the database with the
built-in demo data (clients, cases, hearings, etc.) since the tables
start out empty.

**Every run after that:** your real data — anything added or
changed through the site — is loaded from MySQL. Nothing resets on
restart anymore.

---

## Demo logins

Each account now has its own unique, non-trivial password (no more
shared "1234" across every account):

| Role     | Email               | Password         |
|----------|---------------------|------------------|
| Advocate | advocate@gmail.com  | Advocate@2026!   |
| Staff    | staff@gmail.com     | OfficeStaff#77   |
| Client   | client@gmail.com    | Priya@Legal92    |
| Client   | rahul@gmail.com     | Rahul#Case45     |
| Client   | sneha@gmail.com     | Sneha@Matter18   |
| Intern   | *(generated per-intern on approval)* | *(shown once at approval time)* |

Advocate/staff passwords can be overridden without touching source
code via environment variables:

```
export LEGALDESK_ADVOCATE_PASSWORD=your-own-password
export LEGALDESK_STAFF_PASSWORD=your-own-password
```

⚠️ These are still demo credentials meant for testing the app, not
production secrets — they're committed in this repo, which is fine
for coursework but not for anything holding real client data. Before
any real use: set the environment variables above to something only
you know, and have real clients set their own password through
Register / Forgot Password rather than using the seeded demo ones.

---

## What changed from the original prototype

- Added a full MySQL persistence layer (`database.py` +
  `schema.sql`) — all data now survives a server restart.
- Fixed `/client/payments` and `/client/communication`, which
  previously crashed with a 500 error (missing/mismatched
  templates).
- Fixed the "Paid By" column and "Client Payment Summary" on the
  Payments page, which never populated due to a field-name
  mismatch and a missing calculation.
- Fixed the Staff Dashboard's "Recent Cases" and "Today's Hearings"
  tables, which always rendered empty.
- Added proper branded 404 and 500 error pages (previously missing,
  so a crash showed a raw developer traceback).

---

## Features added in this update

- **Password security** — advocate, staff, and client passwords are now
  hashed (`werkzeug.security`) instead of stored/compared in plaintext.
- **Hearing deadline reminders** — any scheduled hearing within 7 days
  shows a "Today / Tomorrow / In X days" badge on the hearings pages,
  and the Advocate Dashboard has a dedicated upcoming-deadlines card.
- **Real two-way client messaging** — Office Communication and Client
  Messages previously showed hardcoded fake conversations and didn't
  actually submit. Both are now wired to real data: advocate/staff can
  message a specific client, and the client can reply — verified with
  an end-to-end send/receive test.
- **Search & filters** — Clients, Cases, and Hearings pages now support
  status filters (and Cases also filters by case type; Hearings by
  date range) alongside the existing text search.
- **Document e-signature tracking** — documents can be marked "Pending
  Signature" when sent/added; the client sees a "Sign Now" button and
  can mark it "Signed" from their own Documents page.
- **Per-client billing summary** — cases now have a `fee_amount`
  (set when creating a case). The Payments page (staff/advocate) and
  the client's own Payments page show real Total Billed / Total Paid
  / Amount Due, computed from actual case fees and recorded payments
  — not just a running total of whatever's been paid so far.

### New/changed database columns

`schema.sql` has two additions since the original MySQL setup:
- `cases.fee_amount` — the agreed fee for a case, used for billing
- `documents.signature_status` — `Not Required` / `Pending Signature` / `Signed`

If you already ran `schema.sql` once and have an existing `legaldesk`
database, run this once to add the new columns without losing data:

```sql
USE legaldesk;
ALTER TABLE cases ADD COLUMN fee_amount DECIMAL(12,2) DEFAULT 0.00;
ALTER TABLE documents ADD COLUMN signature_status VARCHAR(30) DEFAULT 'Not Required';
```

---

## Intern Portal (new)

The homepage now has an "Internship" link and a promotional section, and
the internship application form is fully wired to a review-and-approve
workflow:

1. A student applies at `/internship` — the application is saved.
2. An advocate or staff member reviews applications at
   **Internship Applications** (linked from their dashboard sidebar) and
   clicks **Approve & Create Account**. This generates an intern login
   and displays a one-time temporary password on screen.
3. The advocate/staff can assign tasks to any approved intern from the
   same page ("+ Assign a Task to an Intern").
4. The intern logs in from the normal Login page using the new **Intern**
   account type, and lands on their own dashboard showing every task
   assigned to them, with a status dropdown (Pending / In Progress /
   Completed) they can update themselves.

### New database tables

Two more tables were added for this feature: `interns` and
`intern_tasks`. If you already ran `schema.sql` before, run this once
to add them without losing existing data:

```sql
USE legaldesk;

CREATE TABLE IF NOT EXISTS interns (
    id           INT PRIMARY KEY,
    full_name    VARCHAR(150) NOT NULL,
    email        VARCHAR(150) NOT NULL,
    password     VARCHAR(255),
    area         VARCHAR(100),
    status       VARCHAR(30) DEFAULT 'Active',
    date_joined  DATE NULL
);

CREATE TABLE IF NOT EXISTS intern_tasks (
    id             INT PRIMARY KEY,
    intern_email   VARCHAR(150),
    title          VARCHAR(200),
    description    TEXT,
    status         VARCHAR(30) DEFAULT 'Pending',
    assigned_date  DATE NULL,
    due_date       DATE NULL
);
```

Verified end-to-end: submitted an application, approved it as advocate,
logged in as the newly created intern, saw the assigned task, and
updated its status — all persisted correctly.

---

## Account Recovery, Audit Trail & Case Notes (new)

- **Forgot Password** — the Login page's "Forgot Password?" link now
  works. Since this app doesn't send real emails, the reset link is
  shown directly on screen after you submit your account type and
  email (works for Advocate, Staff, Client, and Intern accounts).
- **Client profile editing** — clients can now update their own phone
  number and address from their Profile page.
- **Activity Log** — every login, document view, document signature,
  and new client/case now gets recorded. Advocates can view the full
  log from their dashboard sidebar ("Activity Log").
- **Case Notes / Timeline** — each case in the Cases page now has a
  "Notes" button where advocate/staff can log progress notes and see
  a running timeline for that case.

⚠️ Advocate/staff password resets take effect immediately but only
for the running server process — they use the same hashed constants
set from environment variables at startup, so a server restart reverts
to the `LEGALDESK_ADVOCATE_PASSWORD` / `LEGALDESK_STAFF_PASSWORD`
environment variable (or the "1234" default). Client and intern
password resets are fully persistent since those are stored per-record
in MySQL.

### New database tables

Two more tables: `audit_log` and `case_notes`. If you already have an
existing `legaldesk` database, run this once:

```sql
USE legaldesk;

CREATE TABLE IF NOT EXISTS audit_log (
    id         INT PRIMARY KEY,
    actor      VARCHAR(150),
    action     VARCHAR(150),
    details    TEXT,
    timestamp  VARCHAR(30)
);

CREATE TABLE IF NOT EXISTS case_notes (
    id           INT PRIMARY KEY,
    case_number  VARCHAR(50),
    author       VARCHAR(150),
    note         TEXT,
    date         VARCHAR(30)
);
```

Verified end-to-end: requested and used a real password reset link,
edited and persisted a client's profile, confirmed the audit log
captures logins/edits/signatures and is advocate-only, and added a
case note that appears immediately in that case's timeline.

---

## Notifications, Calendar, Invoices & Site Polish (new)

- **Notifications bell** — advocate and staff dashboards now show a
  real notification count (unread messages + pending appointment
  requests) with a working dropdown, not just a static icon.
- **Calendar view** — a new visual month calendar (linked from both
  dashboard sidebars) plots every hearing and appointment on its
  actual date, with Prev/Next month navigation.
- **Printable invoices** — every payment now has a "View" invoice
  link that opens a clean, printable receipt (Print/Save as PDF
  button included), available to staff/advocate and to the client
  who made that payment.
- **FAQ, Terms of Service, and Privacy Policy pages** — added and
  linked from the site footer.
- **Click-to-call & mailto links** — phone numbers and email addresses
  across the homepage and Contact page are now tappable links instead
  of plain text.
- **Real embedded map** — the Contact page's "Google Map can be added
  here later" placeholder is gone; there's now an actual embedded
  Google Map of the office location.
- **Testimonials section** — added to the homepage.

Verified: notification dropdowns render real data for both roles,
calendar correctly plots a hearing on its actual date, invoice pages
load and show the right amount, and all new public pages/links work.

---

## Fee Estimator, Conflict Checker, Case Timeline & Document Generator (new)

- **Legal Fee Estimator** — a public page (`/fee-estimator`, linked from
  the homepage footer) where visitors get an instant estimated fee
  range based on case type, whether it's contested, and complexity.
  Pure client-side calculation with a "Book a Consultation" CTA.
- **Conflict of Interest Checker** — the public Appointment form and
  the internal Add Case form both now have an "Opposing Party" field.
  If that name matches an existing client, the system automatically
  flags it: a warning badge appears on the Appointments page, a red
  banner appears on the Cases page, and both advocate and staff get a
  notification in their bell dropdown. Every flag is also recorded in
  the Activity Log.
- **Case-Status Timeline** — cases now have a `stage` (1 = Intake,
  2 = Evidence Gathering, 3 = Court Date Set, 4 = Closed), set when a
  case is created. Clients see a visual step-by-step progress tracker
  for each of their cases instead of just a status badge.
- **Document Generator** — clients can generate a standard NDA or
  Retainer Agreement pre-filled with their name and case reference,
  from their Documents page, and print/save it as a PDF.

### New database columns

Run these once if you already have an existing `legaldesk` database:

```sql
USE legaldesk;

ALTER TABLE appointments ADD COLUMN opposing_party VARCHAR(150);
ALTER TABLE appointments ADD COLUMN conflict_flag TINYINT(1) DEFAULT 0;
ALTER TABLE cases ADD COLUMN opposing_party VARCHAR(150);
ALTER TABLE cases ADD COLUMN stage INT DEFAULT 1;
```

Verified: submitted an appointment naming an existing client as the
opposing party and confirmed the flag appeared correctly everywhere
(Appointments page, Cases page, both dashboards' notifications, and
the Activity Log); confirmed a case's stage renders the correct step
on the client's visual timeline; and generated both document types
with the client's real name and case reference filled in correctly.

---

## Conflict Checker Upgrade: Fuzzy Matching (new)

The Conflict of Interest checker no longer requires an exact name
match. It now:

- **Normalizes names** before comparing — strips titles (Mr., Mrs.,
  Adv., Dr., etc.), punctuation, and extra whitespace.
- **Uses similarity scoring** (Python's built-in `difflib`) to catch
  near-misses: middle initials, minor typos, or slightly different
  formatting of the same name.
- **Shows the match confidence** — an exact match is labeled as such;
  a fuzzy match shows its percentage (e.g. "92% match") wherever it
  appears, so the advocate knows to double-check rather than assume
  certainty.

Example: naming "Adv. Priya S. Sharma" as an opposing party now
correctly flags a 92% match against the existing client "Priya
Sharma" — this previously would have been missed entirely by exact
matching.

This is still a first-pass flag for human review, not a legal
determination — the match threshold is tuned to catch likely
variants without over-flagging unrelated names.

### New database column

```sql
USE legaldesk;
ALTER TABLE appointments ADD COLUMN conflict_score INT DEFAULT 0;
```

Verified: exact matches, near-misses (titles/initials/typos), and
unrelated names all behave correctly, end-to-end through both the
Appointment form and the Add Case form.

---

## Bug Fix: Client Document Upload Error Handling (found during audit)

While doing a systematic audit (cross-checking every `render_template()`
call in `app.py` against the actual files in `templates/`), one
pre-existing bug from the original project was found and fixed:

**The problem:** if a client tried to upload a document without
entering a document name, or with a disallowed file type, the app
crashed with a 500 error (`TemplateNotFound: client_upload_document.html`)
— because that template file never actually existed. It also crashed
on a plain GET request to the upload page. This had been present since
the original uploaded project and wasn't triggered by any prior testing
because those tests always submitted valid data.

**The fix:** those three code paths now correctly render
`client_documents.html` (the real page) with a proper inline error
banner, instead of pointing at a file that was never created.

Verified: submitting the upload form with a missing document name now
shows a clear validation message instead of crashing, and the upload
page loads correctly on a direct GET request.

---

## Bug Fix: Client Documents Showed Blank Names (found while checking upload)

While confirming the client document upload feature, a second
pre-existing bug (also from the original project, not introduced
later) was found: **every document in the client's Documents list —
uploaded or pre-existing — showed a blank name**, because the
template referenced `document.name` and `document.filename`, but the
actual data fields are named `document_name` and `file_name`.

Upload itself was always working correctly (the file saved and the
record was created) — but the list displaying it back was silently
broken, which made it look like uploads weren't working at all.

**Fixed:** the template now reads the correct field names, with a
safe fallback. Verified both existing demo documents and a freshly
uploaded file now display their real name and filename correctly.

---

## Bug Fixes & Real-World Polish (large batch, from user testing notes)

A round of hands-on testing surfaced several real, confirmed bugs.
All were verified live (not just read in code) and fixed:

- **Settings page — every sidebar link was broken (404).** Every link
  except Dashboard/Logout pointed at non-existent routes like
  `/advocate/clients` instead of `/clients`. All fixed.
- **Settings "Change Password" was decorative** — no form behind it at
  all. Now a real, working flow: verify current password → set and
  confirm a new one. Works for both advocate and staff accounts.
- **Advocate dashboard search bar did nothing** — it was a plain input
  with no form or destination. Built a real `/search` page that
  searches clients, cases, and hearings, and wired the dashboard box
  to it.
- **Add/Send/Receive Document forms (advocate & staff) had no file
  upload field at all**, despite the backend expecting one — meaning
  documents added through those forms never actually had a file
  attached. Fixed all three, and added `.odt` support alongside the
  existing PDF/Word/image types.
- **Internship application review page didn't show the applicant's
  message or resume** — only contact/education fields. Both are now
  shown to the reviewing advocate/staff.
- **Reports page "View Report" buttons only triggered a browser print**
  instead of taking you to the actual records. Client Records, Case
  Records, Hearings, Appointments, and Payments cards now link to
  their real pages.
- **Payments access is now advocate-only.** Staff previously had the
  same payment access as the advocate; that's now restricted —
  staff attempting to reach Payments are redirected back to their
  dashboard, and the Payments link is hidden from their Settings/
  Reports sidebars entirely.
- **A genuine syntax bug was caught during testing**: a `global`
  variable declaration inside the new Settings password-change logic
  was placed after the variable was already read, which is invalid
  in Python and would have crashed the app on that route specifically.
  Fixed and re-verified by actually importing/running the module, not
  just parsing it.

### Footers simplified, site-wide

Per direct request: every footer across the entire site — public
pages and every logged-in page alike — now shows only:

> © 2026 LegalDesk. All Rights Reserved.

The large multi-column footer (Quick Links, Services, Contact, Legal)
has been removed from every page, including the homepage. Internal
pages behind login (dashboards, Clients, Cases, Hearings, Payments,
Documents, Settings, Reports, Office Communication, etc.) now have no
footer at all, since a marketing-style footer doesn't belong on
internal management screens.

All of the above was verified with 54 automated checks (19 targeting
this batch specifically, 35 covering every feature from every prior
session) — all passing.

---

## Round 2 of Bug Fixes (from user testing notes)

- **Client dashboard's own "Messages" sidebar link was dead** (`href="#"`)
  — a client could reach their messages directly by URL, but the link
  on their own dashboard did nothing. Fixed.
- **Advocate/staff had no quick way to message a specific client** —
  added a "💬 Message" button directly on each row of the Clients page,
  which opens Office Communication with that client pre-selected in
  the recipient dropdown.
- **"Organized Records" on the Documents page was just descriptive
  text with no real function.** It's now a real sort feature — by
  client, case, document type, or newest first.
- **Settings "Working Hours" was fully decorative** (a `type="button"`
  that submitted nothing, plus a non-functional per-day toggle grid).
  Replaced with a single real, working field that actually saves and
  now updates the office hours shown on the homepage and Contact page.
- **Advocate/staff had no visibility into intern task progress** — the
  Internship Applications page now shows a live list of every intern
  task and its current status (Pending / In Progress / Completed).
- **Password strength raised**: minimum length is now 6 characters
  (was 4), enforced both in the browser and on the server for new
  client registrations.
- **Payments restricted to advocate-only**, per direct request — staff
  attempting to reach Payments are redirected to their own dashboard,
  and the Payments link is hidden from their Settings/Reports pages.

### Significant bug found and fixed: registration showed no confirmation

While testing the new password-length validation, a serious
pre-existing bug (from the original project, not introduced later)
was found: **successfully registering a new client account showed no
confirmation at all.** The backend correctly created the account and
passed a success message to the template — but `register.html` never
actually displayed that message anywhere. A new client would submit
the form and just see the same blank registration form again, with no
indication that their account had been created.

A complete, ready-made confirmation page (`registration_success.html`)
already existed in the project but had never been wired up. Fixed by
routing successful registrations to that real page, which shows the
new account's name, email, phone, and a direct link to log in.

Verified end-to-end: registered a new account, confirmed the real
success page renders with the correct details, and confirmed the new
account can immediately log in.

### Footers (recap)

Every footer across the whole site — public and logged-in pages alike
— now shows only:

> © 2026 LegalDesk. All Rights Reserved.

All of this was verified with 40 automated checks, all passing.

---

## Final Dead-Link Sweep

Did a full site-wide search for every remaining dead link pattern
(`href="#"`, `action="#"`, `javascript:void`) and found 3 more:

- Clients page "View Client" (mobile button) → now links to that
  client's cases
- Office Communication sidebar "Reports" → now links to the real
  Reports page
- Register page "terms and conditions" → now links to the real
  Terms of Service page

Confirmed via a repeated sweep: zero dead links remain anywhere in
the project.

---

## Security/Deployment Fixes (from database & config audit)

Three items from an external audit were checked against the actual
code and addressed:

1. **Hardcoded secret key — fixed.** `app.secret_key` now reads from
   the `SECRET_KEY` environment variable, falling back to a clearly
   labeled dev-only key if unset:
   ```
   export SECRET_KEY=your-random-production-secret
   ```

2. **Debug mode always on — fixed.** `debug=True` is now controlled
   by the `FLASK_DEBUG` environment variable (defaults to `true` for
   local development convenience). For a real deployment:
   ```
   export FLASK_DEBUG=false
   ```
   This matters beyond just log verbosity — Flask's debug mode
   exposes an interactive code-execution console if an error page is
   ever reached by an untrusted user, so it should be off wherever
   the app is reachable by anyone other than the developer.

3. **`database.py`'s `save()` rewrites the whole table on every
   change — reviewed, not changed.** This was a deliberate simplicity
   trade-off from when the database layer was first built (documented
   in that file's own docstring). Two things worth knowing:
   - **Crash safety is fine as-is**: the DELETE and every INSERT run
     inside one uncommitted transaction (this connector defaults to
     `autocommit=False`) and only commit once at the end, so a crash
     mid-save rolls back cleanly — no half-written table.
   - **True concurrent-user safety is a real, unaddressed limitation**:
     if two people trigger a save on the same table at the same
     moment, one's write can still be lost. Fixing this properly means
     moving every route off the "in-memory list mirrored to MySQL"
     pattern and onto direct per-record `INSERT`/`UPDATE`/`DELETE`
     statements — a significant rearchitecture, not a small patch, so
     it hasn't been done here. Fine for a single-office / low-concurrency
     tool or a college project; worth revisiting before any real
     multi-user production use.

---

## Significant Bug Fixed: Clients Added by Advocate Had Broken Passwords

While updating the demo passwords, a real bug was found in the
**"Add Client"** form (used by advocate/staff to register a client
directly, as opposed to a client self-registering): if no password
was typed in, the client record was silently given a **plaintext,
unhashed password of "1234"**.

This was worse than it sounds — because every login check in the app
verifies passwords via `check_password_hash()`, which expects a real
hash, not raw text, a client created this way **could never actually
log in at all**, even with the correct "1234". The account was
created but permanently inaccessible until someone used the
Forgot Password flow to reset it.

**Fixed:**
- The Add Client form now has an optional password field.
- If left blank, a strong random password is generated automatically,
  properly hashed, and shown once on screen (same pattern as intern
  account approval) so the advocate can share it with the client.
- If the advocate types a specific password, that's hashed and used
  instead — no more silent "1234" fallback.

Verified end-to-end: created a client with an auto-generated password
and confirmed it actually logs in; created another with a manually
chosen password and confirmed that logs in too.

### All demo account passwords are now unique (recap)

See the "Demo logins" table above — every seeded account (advocate,
staff, and all three demo clients) now has its own distinct, non-trivial
password instead of everything sharing "1234".

---

## Password Storage — Full Codebase Sweep

After finding the Add Client bug above, every single place in the
codebase that writes or checks a password was audited directly (not
just spot-checked):

**Every password write** goes through `generate_password_hash()`:
demo clients, self-registration, Add Client (advocate/staff), intern
account creation on approval, and both password-reset flows.

**Every password check** goes through `_safe_check_password()` /
`check_password_hash()` — confirmed zero plaintext `==` comparisons
remain anywhere in the file.

No further issues found.

---

## Internship Selection/Rejection Status (new)

A real gap was fixed: previously, when an advocate approved an
internship application, only the *advocate* saw a confirmation on
screen — the applicant themselves had no way to find out they were
selected, and there was no "rejected" outcome at all.

Now:
- Every application has a real status: **Pending**, **Approved**, or
  **Rejected**.
- Advocate/staff can now **Reject** an application, not just approve
  it — with a confirmation prompt since it's a final action.
- The Internship Applications review page shows a live status badge
  on every applicant (⏳ Pending / ✓ Approved / ✗ Rejected).
- A new public page, **Check Your Application Status**
  (`/internship/status`, linked from the internship page's submission
  confirmation), lets any applicant enter the email they applied with
  to see exactly where they stand — since this project has no real
  email-sending capability, this is the applicant's way to find out.
- Internship applications are now also persisted to MySQL (previously
  they only lived in memory and were lost on every server restart).

### New database table

```sql
USE legaldesk;

CREATE TABLE IF NOT EXISTS internship_applications (
    id               INT PRIMARY KEY,
    full_name        VARCHAR(150),
    email            VARCHAR(150),
    phone            VARCHAR(30),
    college          VARCHAR(200),
    course           VARCHAR(100),
    year             VARCHAR(30),
    area             VARCHAR(100),
    duration         VARCHAR(50),
    message          TEXT,
    resume_filename  VARCHAR(255),
    date             VARCHAR(30),
    status           VARCHAR(30) DEFAULT 'Pending'
);
```

Verified end-to-end: submitted an application, confirmed it starts as
Pending and shows that on the status-check page, rejected it and
confirmed the status page updates accordingly, then repeated for an
approved application.

## Homepage Footer Restored (full version)

Per direct request, the homepage now has its full footer back —
Brand, Quick Links, Services, Legal (FAQ/Terms/Privacy), and Contact
columns — while every other page keeps the simplified
"© 2026 LegalDesk. All Rights Reserved." footer (or no footer at all,
for pages behind login), as established earlier.
